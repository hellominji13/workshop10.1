import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, forecast_flu as fcf
plt.rcParams['font.family']='Noto Sans CJK JP'
FL=pickle.load(open('flu_scen.pkl','rb')); CV=pickle.load(open('covid_scen.pkl','rb'))
R=fcf.REPORT; fi=[fcf.ALLW.index(w) for w in R]; ci=[CV['ALLW'].index(w) for w in R]; x=np.arange(1,50)
hist=c.week_range(202631,202639); xh=np.arange(-len(hist)+1,1); F=fcf.ff.F; C=c.load_covid()
fig,ax=plt.subplots(1,2,figsize=(11,3.2))
for a,X,obs,cl,tt in [(ax[0],FL['REP']['ili'][:,fi],F.loc[hist,'ILI'],'#2a6fdb','인플루엔자 ILI (300개소)'),(ax[1],CV['out']['REP'][:,ci],C.loc[hist,'ARI'],'#7b3fbf','코로나19 입원 (ARI)')]:
    q=np.quantile(X,[.025,.1,.25,.5,.75,.9,.975],axis=0)
    a.fill_between(x,q[0],q[6],color=cl,alpha=.12,label='95%'); a.fill_between(x,q[1],q[5],color=cl,alpha=.2,label='80%'); a.fill_between(x,q[2],q[4],color=cl,alpha=.3,label='50%'); a.plot(x,q[3],color=cl,lw=2,label='중앙')
    a.plot(xh,obs,'ko',ms=3); a.set_title(tt,fontsize=10)
    tk=[1,10,19,27,35,44]; a.set_xticks(tk); a.set_xticklabels([f'{R[i-1]//100%100}-{R[i-1]%100:02d}' for i in tk],fontsize=8); a.grid(alpha=.3)
ax[0].axhline(12.9,ls='--',color='gray',lw=1); ax[0].legend(fontsize=7,ncol=2)
fig.tight_layout(); fig.savefig('fig/brief.png',dpi=130)
