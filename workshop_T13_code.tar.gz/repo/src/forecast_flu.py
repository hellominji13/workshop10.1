"""인플루엔자 시나리오 전망 (2026-40 ~ 2027-35). 기점 2026-39."""
import numpy as np, pickle, common as c, flu, fit_flu as ff, flu_now as fn, hosp_flu as hf
QL=np.array([0.025,0.10,0.25,0.50,0.75,0.90,0.975])
fit=pickle.load(open('flu_fit.pkl','rb')); G0,LOC=ff.unpack(fit['x'])
POST=pickle.load(open('now.pkl','rb')); BG=pickle.load(open('bg.pkl','rb')); HP=pickle.load(open('hosp_flu.pkl','rb'))
ALLW=c.week_range(202626,202735); REPORT=c.week_range(202640,202735); i40=ALLW.index(202640)
SH=1/(1+np.exp(-LOC[:8,:,0]))            # 과거 8절기 적합 감수성 수준
S_H3_2526=SH[7,1]
# 과거 절기 아형별 '발현 주' (ILI+ ≥ 1 첫 주, 36주 이후) → 유입 시점 경험분포
def onsets(k):
    out=[]
    for a,b in ff.SEASONS[:8]:
        w=c.week_range(a,b); v=ff.F.loc[w,k+'p'].values
        idx=np.where(v>=1.0)[0]
        if len(idx) and v.max()>=3: out.append(idx[0])   # 절기 시작(36주)부터의 주 수
    return out
ON={k:onsets(k) for k in ['H3','B']}
P_PRESENT={k:len(ON[k])/8 for k in ON}
P_SUMMER=2/9   # 2016~19, 2022~26 여름 9회 중 27~35주 유행기준 초과 2회(2023, 2026)
def wk_from36(n): return c.next_week(202636,n)
def bgline(yw,a):
    t=2*np.pi*(yw%100)/52.18; b=BG['b']
    return (b[1]+b[2]*np.cos(t)+b[3]*np.sin(t)+b[4]*np.cos(2*t)+b[5]*np.sin(2*t))*np.exp(a)
def run(scn,seed=0,cov=None,vstart=39,N=None,s_fix=None):
    rng=np.random.default_rng(seed); M=len(POST['s']) if N is None else N
    cov=flu.COV if cov is None else cov
    ili=np.zeros((M,len(ALLW))); hosp=np.zeros_like(ili); posH3B=np.zeros_like(ili); sub=np.zeros((M,len(ALLW),3)); Sfin=np.zeros((M,3,6)); infl=np.zeros((M,6))
    # 비인플루엔자 이상치 초기값 (39주)
    o39=ff.F.loc[202639]; a39=np.log(max(o39.ILI/G0['hrep']-1.66*o39.ILI*o39.pos/100,1)/bgline(202639,0))
    for j in range(M):
        g=dict(zip(ff.G,POST['GV'][j])); sig=ff.sigma(g)
        sH1=POST["s"][j] if s_fix is None else s_fix; I0=np.zeros((3,6)); I0[0]=np.exp(POST["lI"][j])
        sk={'H3':rng.choice(SH[:,1]),'B':rng.choice(SH[:,2])}
        seeds=[None]*len(ALLW)
        def add(k,n36):
            yw=wk_from36(n36)
            if yw in ALLW and yw>=202640:
                t=ALLW.index(yw); e=np.zeros((3,6)); e[1 if k=='H3' else 2]=1e-5
                seeds[t]=e if seeds[t] is None else seeds[t]+e
        if scn=='F2':
            sk['H3']=S_H3_2526; add('H3',int(rng.integers(9,12)))         # 45~47주 유입 → 48주 전후 검출률 상승
        if scn in ('REP',):
            for k in ['H3','B']:
                if rng.random()<P_PRESENT[k]: add(k,max(int(rng.choice(ON[k]))-2+int(rng.integers(-2,3)),4))
        reset=None
        if scn=='REP' and rng.random()<P_SUMMER:     # 여름 신규 계통 사건 (과거 9개 여름 중 2회)
            tt=ALLW.index(int(rng.choice(c.week_range(202722,202730)))); kk=int(rng.integers(3))
            reset={tt:(kk,np.minimum(rng.choice(POST['s'])*sig[kk],0.995))}
        S0=np.zeros((3,6)); S0[0]=np.minimum(sH1*sig[0],0.995)
        S0[1]=np.minimum(sk['H3']*sig[1],0.995); S0[2]=np.minimum(sk['B']*sig[2],0.995)
        # 전파력 과정잡음: 기점 이후 로그 AR(1) (ρ=0.8, sd=0.05)
        u=np.zeros(len(ALLW))
        for t in range(i40,len(ALLW)): u[t]=0.8*u[t-1]+rng.normal(0,0.05)
        qm=g['R0']/flu.R0*POST['m'][j]*np.exp(u)
        inc,st=flu.simulate(ALLW,S0,I0,g['theta'],g['vac_school'],g['hol_red'],cov=cov,vstart=vstart,qmult=qm,seed_add=seeds,reset=reset)
        tot,age=flu.obs_ili(inc,np.exp(g['logkappa']))
        a=a39; bgv=np.zeros(len(ALLW))
        for t,yw in enumerate(ALLW):
            if t>ALLW.index(202639): a=BG['rho']*a+rng.normal(0,BG['sd'])
            bgv[t]=bgline(yw,a if t>=ALLW.index(202639) else 0)
        hol=np.array([g['hrep'] if yw in c.HOLIDAY else 1 for yw in ALLW])
        plus=tot.sum(1)
        ili[j]=hol*(1.66*plus+bgv)*np.exp(rng.normal(0,0.08,len(ALLW)))
        hosp[j]=HP['eta']*hf.hosp_index(inc)*np.exp(rng.normal(0,0.25))*np.exp(rng.normal(0,0.15,len(ALLW)))
        posH3B[j]=100*(tot[:,1]+tot[:,2])/np.maximum(ili[j]/hol,1e-6)
        sub[j]=tot; Sfin[j]=st[0]; infl[j]=inc.sum((0,1))
    return dict(ili=ili,hosp=hosp,posH3B=posH3B,sub=sub,S=Sfin,attack=infl)
def summarize(o,key='ili'):
    i=[ALLW.index(w) for w in REPORT]; x=o[key][:,i]
    return dict(q=np.quantile(x,QL,axis=0),pkw=np.quantile(x.argmax(1)+1,QL),pkv=np.quantile(x.max(1),QL),cum=np.quantile(x.sum(1),QL))
if __name__=='__main__':
    print('onsets',ON,P_PRESENT,'S_H3_2526',S_H3_2526)
    out={}
    for k,s in enumerate(['F1','F2','REP']):
        o=run(s,seed=10+k); out[s]=o; sm=summarize(o)
        i48=ALLW.index(202648)
        print(s,'pk wk',sm['pkw'][[1,3,5]],'pk',sm['pkv'][[1,3,5]].round(1),'cum',sm['cum'][[1,3,5]].round(0),
              'H3B>=5 after48',np.mean((o['posH3B'][:,i48:]>=5).any(1)).round(2),'hosp pk',np.quantile(o['hosp'][:,i40:].max(1),[.1,.5,.9]).round(0))
        print('  median 40-48',np.median(o['ili'][:,i40:i40+9],0).round(1))
    pickle.dump(out,open('flu_scen.pkl','wb'))
