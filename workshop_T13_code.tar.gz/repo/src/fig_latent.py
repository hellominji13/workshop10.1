"""숨겨진 dynamics: 같은 관측(ILI)을 만드는 서로 다른 숨은 감염 규모 — 식별 문제와 해결책."""
import os, numpy as np, pickle, subprocess, json, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import common as c
plt.rcParams['font.family']='Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus']=False
RES={}
for tag,pc in [('pc03',0.3),('pc05',0.5),('pc07',0.7)]:
    d=f'sens/{tag}' if tag!='pc05' else '.'
    code=f'''
import os,sys,pickle,numpy as np
os.environ["P_CONS"]="{pc}"
sys.path.insert(0,".")
import common as c, flu, fit_flu as ff
fit=pickle.load(open("flu_fit.pkl","rb")); r,keep=ff.resid(fit["x"],True)
i=6                      # 2024-25절기
w,inc,tot,age=keep[i]
obs=np.nansum(ff.F.loc[w,["H1p","H3p","Bp"]].values,1)
out=dict(w=[int(x) for x in w],model=[float(x) for x in tot.sum(1)],obs=[float(x) for x in obs],
         inf=float((inc.sum((0,1))*c.N).sum()),kappa=float(flu.KAPPA),R0=float(dict(zip(ff.G,fit["x"][:ff.NG]))["R0"]))
pickle.dump(out,open("/tmp/lat_{tag}.pkl","wb"))
'''
    subprocess.run(['python3','-c',code],cwd=d,check=True,capture_output=True)
    RES[tag]=pickle.load(open(f'/tmp/lat_{tag}.pkl','rb'))
for k,v in RES.items(): print(k,'kappa',round(v['kappa'],2),'R0',round(v['R0'],2),'감염',round(v['inf']/1e6,1),'백만')
pickle.dump(RES,open('latent_demo.pkl','wb'))
