import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import flu, common as c
plt.rcParams['font.family']='Noto Sans CJK JP'
O=pickle.load(open('opt_results.pkl','rb')); K=pickle.load(open('opt_keep65.pkl','rb'))
S={'현행 (39주 시작)':(np.r_[flu.COV,39],O['cur']),'최적 A: 65세 이상 유지':(K['x'],K),'최적 B: 연령 제한 없음':(O['opt_same']['x'],O['opt_same'])}
fig,ax=plt.subplots(1,3,figsize=(17,4.3)); cols=['#95a5a6','#1f3a5f','#2e8b84']; w=0.27
for i,(k,(x,r)) in enumerate(S.items()):
    ax[0].bar(np.arange(6)+(i-1)*w,np.clip(x[:6],0,1)*100,w,color=cols[i],label=f'{k} · 시작 {x[6]:.0f}주')
ax[0].set_xticks(range(6)); ax[0].set_xticklabels(['0–6','7–12','13–18','19–49','50–64','65+']); ax[0].set_ylabel('접종률 (%)'); ax[0].legend(fontsize=8,loc='upper center',bbox_to_anchor=(0.5,-0.12),ncol=3); ax[0].set_title('같은 백신 물량(1,973만 회)의 연령 배분')
names=list(S); hosp=[S[k][1]['hosp'] for k in names]; med=[(S[k][1]['out']+S[k][1]['hosp_cost'])/1e8 for k in names]
b=ax[1].bar(range(3),med,color=cols)
for i,v in enumerate(med): ax[1].text(i,v+30,f'{v:,.0f}억\n(입원 {hosp[i]/1e4:.1f}만 건)',ha='center',fontsize=9)
ax[1].set_xticks(range(3)); ax[1].set_xticklabels(['현행','최적 A','최적 B']); ax[1].set_ylim(0,max(med)*1.3); ax[1].set_title('외래+입원 진료비 (전국 환산, 억 원)')
for h,cl,lb in [(O['hist1'],cols[2],'최적 B'),(K['hist'],cols[1],'최적 A')]: ax[2].plot(h,color=cl,lw=2,label=lb)
ax[2].set_xlabel('세대 (generation)'); ax[2].set_ylabel('목적함수: 진료비 (억 원)'); ax[2].set_title('차분진화 수렴'); ax[2].legend()
fig.tight_layout(); fig.savefig('fig/q3_opt.png',dpi=120)
