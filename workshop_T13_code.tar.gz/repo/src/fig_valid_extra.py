import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c
plt.rcParams['font.family']='Noto Sans CJK JP'
CVv=pickle.load(open('covid_valid.pkl','rb')); RV=pickle.load(open('rsv_valid.pkl','rb'))
fig,ax=plt.subplots(1,3,figsize=(17,4))
def pan(a,FW,q,y,tt,cl):
    x=np.arange(len(FW)); a.fill_between(x,q[0],q[6],color=cl,alpha=.15); a.fill_between(x,q[1],q[5],color=cl,alpha=.3); a.plot(x,q[3],color=cl,lw=2); a.plot(x,y,'ko',ms=3)
    tk=x[::8]; a.set_xticks(tk); a.set_xticklabels([f'{FW[i]//100%100}-{FW[i]%100:02d}' for i in tk],fontsize=8); a.set_title(tt,fontsize=10.5,loc='left'); a.spines[['top','right']].set_visible(False)
pan(ax[0],CVv['FW'],CVv['q'],CVv['y'],f"ARI — 코로나19 기점 2025-30 → 52주\nWIS {CVv['wis']:.1f} (기준모형 {CVv['base']:.1f})",'#7b3fbf')
for k,O in enumerate([202340,202440]):
    r=RV[O]; pan(ax[k+1],r['FW'],r['q'],r['y'],f"RSV 기점 {O//100}-{O%100} → 이듬해 17주\nWIS {r['wis']:.1f} (기준모형 {r['base']:.1f})",'#2a9d5c')
fig.tight_layout(); fig.savefig('fig/valid_extra.png',dpi=120)
