import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, forecast_flu as fcf
plt.rcParams['font.family']='Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus']=False
NAVY='#1f3a5f'; TEAL='#2e8b84'; GRAY='#c9d1da'
# 1) 정책: 막대 + 연령별 감염 감소율 히트맵 (원자료)
P=pickle.load(open('policy_runs.pkl','rb')); ks=list(P)
lab={'P0 접종 없음':'P0  접종 없음','P1 예년 일정(42주 시작)':'P1  예년 일정','P2 실제 일정(39주, 앞당김)':'P2  조기 접종','P3 13~18세 국가접종 확대(70%)':'P3  청소년 확대','P4 19~64세 접종률 +15%p':'P4  성인 확대'}
fig=plt.figure(figsize=(15,6)); a1=fig.add_axes([0.08,0.17,0.36,0.68]); a2=fig.add_axes([0.56,0.17,0.36,0.68]); cb=fig.add_axes([0.935,0.17,0.012,0.68])
v=[P[k]['hcum'] for k in ks]; col=[GRAY,GRAY,NAVY,TEAL,TEAL]
a1.barh(range(5),v,color=col,height=0.6); a1.set_yticks(range(5)); a1.set_yticklabels([lab[k] for k in ks],fontsize=11); a1.invert_yaxis()
ref=P[ks[2]]['hcum']; a1.axvline(ref,ls='--',color='gray',lw=1)
for i,k in enumerate(ks):
    a1.text(v[i]+250,i-0.08,f"{v[i]:,.0f}",fontsize=11,fontweight='bold',color=NAVY); a1.text(v[i]+250,i+0.22,'기준' if i==2 else f"{P[k]['d_hcum_pct']:+.0f}%",fontsize=9,color='#555')
a1.set_xlim(0,max(v)*1.25); a1.set_xlabel('절기 누적 입원 (표본감시, 명)'); a1.spines[['top','right']].set_visible(False)
a1.set_title('01  접종 전략별 누적 입원',loc='left',fontsize=13,fontweight='bold',color=NAVY)
base0=P[ks[0]]['attack']; M=np.array([(1-P[k]['attack']/base0)*100 for k in ks[1:]])
im=a2.imshow(M,cmap='Blues',vmin=0,vmax=max(60,M.max()),aspect='auto')
for i in range(M.shape[0]):
    for j in range(6): a2.text(j,i,f'{M[i,j]:.0f}%',ha='center',va='center',fontsize=11,fontweight='bold',color='white' if M[i,j]>35 else NAVY)
a2.set_yticks(range(4)); a2.set_yticklabels([lab[k] for k in ks[1:]],fontsize=11); a2.set_xticks(range(6)); a2.set_xticklabels(['0–6세','7–12세','13–18세','19–49세','50–64세','65세 이상'])
a2.set_title('02  연령별 감염 감소율 (접종 없음 대비)',loc='left',fontsize=13,fontweight='bold',color=NAVY); fig.colorbar(im,cax=cb)
fig.text(0.08,0.05,'시나리오 조건   P1 42주 시작   P2 39주 시작(현행)   P3 13–18세 접종률 70%   P4 19–64세 접종률 +15%p   ·   같은 난수로 짝지은 비교, 중앙값',fontsize=9.5,color='#555')
fig.savefig('fig/policy.png',dpi=130)
# 2) 대표 전망(brief) 제목: ILI / ARI
FL=pickle.load(open('flu_scen.pkl','rb')); CV=pickle.load(open('covid_scen.pkl','rb'))
R=fcf.REPORT; fi=[fcf.ALLW.index(w) for w in R]; ci=[CV['ALLW'].index(w) for w in R]; x=np.arange(1,50)
hist=c.week_range(202631,202639); xh=np.arange(-len(hist)+1,1); F=fcf.ff.F; C=c.load_covid()
fig,ax=plt.subplots(1,2,figsize=(11,3.4))
for a,X,obs,cl,tt in [(ax[0],FL['REP']['ili'][:,fi],F.loc[hist,'ILI'],'#2a6fdb','ILI'),(ax[1],CV['out']['REP'][:,ci],C.loc[hist,'ARI'],'#7b3fbf','ARI')]:
    q=np.quantile(X,[.025,.1,.25,.5,.75,.9,.975],axis=0)
    a.fill_between(x,q[0],q[6],color=cl,alpha=.12,label='95%'); a.fill_between(x,q[1],q[5],color=cl,alpha=.2,label='80%'); a.fill_between(x,q[2],q[4],color=cl,alpha=.3,label='50%'); a.plot(x,q[3],color=cl,lw=2,label='중앙값')
    a.plot(xh,obs,'ko',ms=3,label='관측'); a.set_title(tt,fontsize=12)
    tk=[1,10,19,27,35,44]; a.set_xticks(tk); a.set_xticklabels([f'{R[i-1]//100%100}-{R[i-1]%100:02d}' for i in tk],fontsize=8); a.grid(alpha=.3)
ax[0].axhline(12.9,ls='--',color='gray',lw=1); ax[0].legend(fontsize=7,ncol=2)
fig.tight_layout(); fig.savefig('fig/brief.png',dpi=130)
# 3) 시나리오 3칸
colr={'F1':'#2a6fdb','F2':'#e0542e','REP':'#444444'}
fig,ax=plt.subplots(1,3,figsize=(18,4.8),sharey=True); hw=c.week_range(202627,202639)
for k,s in enumerate(['REP','F1','F2']):
    o=FL[s]; q=np.quantile(o['ili'],[.025,.1,.25,.5,.75,.9,.975],axis=0); xx=np.arange(len(fcf.ALLW)); m=xx>=fcf.ALLW.index(202639)
    for lo,hi,al in [(0,6,.12),(1,5,.2),(2,4,.3)]: ax[k].fill_between(xx[m],q[lo][m],q[hi][m],color=colr[s],alpha=al)
    ax[k].plot(xx[m],q[3][m],color=colr[s],lw=2); ax[k].plot([fcf.ALLW.index(w) for w in hw],F.loc[hw,'ILI'],'ko',ms=3.5)
    ax[k].axhline(12.9,ls='--',color='gray',lw=1)
    tk=[fcf.ALLW.index(w) for w in [202627,202640,202648,202701,202710,202720,202730]]; ax[k].set_xticks(tk); ax[k].set_xticklabels(['26-27','26-40','26-48','27-01','27-10','27-20','27-30'],fontsize=8)
    ax[k].set_title({'REP':'ILI — 대표 전망 (REP)','F1':'ILI — F1: 신규 아형 유입 없음','F2':'ILI — F2: 48주 전후 A(H3N2) 유입'}[s])
ax[0].set_ylabel('ILI (외래 1,000명당)'); fig.tight_layout(); fig.savefig('fig/flu_forecast.png',dpi=110)
# 4) H1 감수성 민감도
S=pickle.load(open('sens_s.pkl','rb')); fig,ax=plt.subplots(figsize=(9,3.8)); cc={0.6:'#9ecae1',0.75:'#4292c6',0.89:'#08306b'}
for s,v in S.items():
    ax.fill_between(x,v['q'][0],v['q'][2],color=cc[s],alpha=.15); ax.plot(x,v['q'][1],color=cc[s],lw=2.2,label=f"s(H1)={s}: 정점 {v['pk'][1]:.0f}, 누적 {v['cum']:,.0f}")
ax.axhline(12.9,ls='--',color='gray',lw=1); tk=[1,10,19,27,35,44]; ax.set_xticks(tk); ax.set_xticklabels([f'{R[i-1]//100%100}-{R[i-1]%100:02d}' for i in tk])
ax.set_title('ILI — 현재 A(H1N1)pdm09 초기 감수성 인구 비율 s에 따른 대표 전망'); ax.legend(fontsize=9); ax.grid(alpha=.3)
fig.tight_layout(); fig.savefig('fig/sens_s.png',dpi=120)
print('ok')
