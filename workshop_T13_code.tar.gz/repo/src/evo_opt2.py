"""비용 제약 아래 바이러스에 가장 유리한 형질을 차분진화로 탐색 + 실제 관측 변이 비교."""
import numpy as np, pickle, common as c, fit_covid as fc
from scipy.optimize import differential_evolution
from evo2 import invade, ALL
WKS=[c.next_week(202640,k) for k in range(0,96)]
def tau_max(eps,k,p): return max(1-k*eps**p,0.05)
def optimize(k,p,seed=1,maxiter=30):
    hist=[]
    def obj(z):
        eps=float(np.clip(z[0],0,0.95)); tau=min(float(np.clip(z[1],0.3,1.5)),tau_max(eps,k,p))
        w=WKS[int(np.clip(round(z[2]),0,len(WKS)-1))]
        return -invade(eps,tau,w)[0]/1e6
    r=differential_evolution(obj,[(0,0.95),(0.3,1.5),(0,len(WKS)-1)],seed=seed,maxiter=maxiter,popsize=10,
                             tol=1e-8,polish=False,callback=lambda xk,convergence=None: hist.append(-obj(xk)))
    eps=float(np.clip(r.x[0],0,0.95)); tau=min(float(np.clip(r.x[1],0.3,1.5)),tau_max(eps,k,p)); w=WKS[int(round(r.x[2]))]
    f,res,Sv=invade(eps,tau,w)
    return dict(k=k,p=p,eps=eps,tau=tau,week=w,fit=f,res=res,Sv=Sv,hist=hist)
if __name__=='__main__':
    OUT={}
    for k,p in [(0.0,1.0),(0.3,1.0),(0.6,1.0),(1.0,1.0),(0.6,2.0)]:
        o=optimize(k,p); OUT[f'{k}_{p}']=o
        print(f'비용 k={k}, p={p}  →  ε*={o["eps"]:.2f}, τ*={o["tau"]:.2f}, 유입 {o["week"]}, 적합도 {o["fit"]/1e6:.1f}백만',flush=True)
    cf=pickle.load(open('covid_fit_best.pkl','rb')); e=dict(zip(fc.P,cf['x']))
    OBS={'인플루엔자 아형 교체(A(H3N2)→B 등)':1.00,'코로나19 KP 계통군':e['e_KP'],'코로나19 LP.8.1':e['e_LP.8.1'],
         '코로나19 NB.1.8.1/PQ.2':e['e_NB'],'코로나19 BA.3.2':e['e_BA.3.2'],'코로나19 PQ.16.1.1':e['e_PQ.16.1.1']}
    print({k:round(v,2) for k,v in OBS.items()})
    pickle.dump(dict(OUT=OUT,OBS=OBS),open('evo_opt2.pkl','wb'))
