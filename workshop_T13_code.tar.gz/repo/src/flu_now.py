"""현재 절기(2026-27) H1 파동 nowcast: 사전표본 → 2026-26~39주 H1 ILI+ 우도 가중 → 재표집 (SIR)."""
import numpy as np, pickle, common as c, flu, fit_flu as ff
fit=pickle.load(open('flu_fit.pkl','rb')); G,LOC=ff.unpack(fit['x'])
J=fit['jac']; s2=(fit['fun']**2).sum()/(len(fit['fun'])-len(fit['x']))
INFL=9.0   # 잔차 자기상관(ρ≈0.8) 보정: (1+ρ)/(1-ρ)
covg=np.linalg.pinv(J[:,:ff.NG].T@J[:,:ff.NG])*s2*INFL
W=c.week_range(202626,202639); OBS=ff.F.loc[W,'H1p'].values
def draw_globals(n,rng):
    x=rng.multivariate_normal(fit['x'][:ff.NG],covg,n)
    lo,hi=ff.LB[:ff.NG],ff.UB[:ff.NG]; return np.clip(x,lo,hi)
def sim_cur(gv,s,I0,m,weeks):
    g=dict(zip(ff.G,gv)); S0=np.minimum(s*ff.sigma(g),0.995); S0[1:]=0.3
    I=np.zeros((3,6)); I[0]=I0
    inc,st=flu.simulate(weeks,S0,I,g['theta'],g['vac_school'],g['hol_red'],qmult=np.full(len(weeks),g['R0']/flu.R0*m),vstart=39)
    return inc,st,g
def nowcast(N0=20000,N=1000,seed=1):
    rng=np.random.default_rng(seed)
    GV=draw_globals(N0,rng); s=rng.uniform(0.4,1.0,N0); lI=rng.uniform(-16,-7,N0); m=np.exp(rng.normal(0,0.15,N0))
    ll=np.zeros(N0); sd=0.35
    for j in range(N0):
        inc,st,g=sim_cur(GV[j],s[j],np.exp(lI[j]),m[j],W)
        tot,_=flu.obs_ili(inc,np.exp(g['logkappa']))
        hol=np.array([g['hrep'] if yw in c.HOLIDAY else 1 for yw in W])
        ll[j]=-0.5*np.sum(((np.sqrt(tot[:,0]*hol)-np.sqrt(OBS))/sd)**2)
    w=np.exp(ll-ll.max()); w/=w.sum(); ess=1/np.sum(w**2)
    idx=rng.choice(N0,N,p=w)
    return dict(GV=GV[idx],s=s[idx],lI=lI[idx],m=m[idx],ess=ess)
if __name__=='__main__':
    print('global sd',dict(zip(ff.G,np.sqrt(np.diag(covg)).round(3))))
    post=nowcast(); pickle.dump(post,open('now.pkl','wb'))
    print('ESS',post['ess']); 
    for k in ['s','m']: print(k,np.quantile(post[k],[.05,.5,.95]).round(3))
