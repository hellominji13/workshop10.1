"""코로나19: 연령(6) SEIRS + 변이 우세화 시점의 면역회피(R→S 일부 복귀). 공통 접촉행렬 C(t) 사용.
β_ab(t) = q_cov · exp(-θ_cov·(AH-AH̄)) · sus_a · C_ab(t)
sus: 연령별 감수성 (Davies 2020 Nat Med: 0~19세는 성인의 약 절반)
입원 = η_cov · Σ_a ihr_a · N_a · 감염_a"""
import numpy as np, common as c
LAT=3.0; INF=5.0           # Omicron 잠복 ~3일 (Wu 2022 메타분석 3.4일), 감염기간 ~5일 (Puhach 2023)
SUS=np.array([0.40,0.40,0.45,0.80,0.85,0.88])
IHR=np.array([1.0,0.2,0.2,0.4,1.5,12.0])     # 감염당 입원 상대위험, 연령에 따라 지수 증가 (Ward 2022, Nyberg 2022 Omicron)
# 변이 우세화 (질병관리청 점유율 자료, 점유율 50% 도달/교체 월) → 주차
EVENTS={'KP.3':202430,'LP.8.1/XEC':202506,'NB.1.8.1':202522,'BA.3.2':202614,'PQ.16.1.1':202632}
AHBAR=c.AH.mean()
def ngm_q(R0):
    C=c.contact(202645,1,1); ev=np.max(np.abs(np.linalg.eigvals(SUS[:,None]*C*INF))); return R0/ev
def simulate(weeks,p,vac_school,hol_red,state=None,escapes=None,qmult=None,vac=None):
    """p: dict(R0,theta,wane_days,S0,I0,esc{name:frac}). escapes: {yw: frac}"""
    q=ngm_q(p['R0']); om=1/p['wane_days']
    if state is None:
        S=np.full(6,p['S0']); I=np.full(6,p['I0']); E=I*LAT/INF; R=1-S-E-I
    else: S,E,I,R=[x.copy() for x in state]
    inc=np.zeros((len(weeks),6))
    for t,yw in enumerate(weeks):
        C=c.contact(yw,vac_school,hol_red); f=np.exp(-p['theta']*(c.ah_at(yw)-AHBAR))
        qm=1 if qmult is None else qmult[t]
        B=q*qm*f*SUS[:,None]*C
        e=(escapes or {}).get(yw,0.0)
        for d in range(7):
            if e>0:   # 우세화 주변 4주에 걸쳐 회피(하루 단위로 분산)
                pass
            lam=B@I; nE=lam*S
            S=S-nE+om*R; E=E+nE-E/LAT; I=I+E/LAT-I/INF; R=R+I/INF-om*R
            inc[t]+=E/LAT
        if e>0:
            mv=R*e; R=R-mv; S=S+mv
        if vac is not None:
            v=vac(yw)
            if v is not None: mv=S*v; S=S-mv; R=R+mv
    return inc,(S,E,I,R)
def hosp(inc,eta): return eta*(inc*c.N*IHR).sum(1)
