import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, forecast_flu as fcf
plt.rcParams['font.family']='Noto Sans CJK JP'
FL=pickle.load(open('flu_scen.pkl','rb')); CV=pickle.load(open('covid_scen.pkl','rb'))
R=fcf.REPORT; fi=[fcf.ALLW.index(w) for w in R]; ci=[CV['ALLW'].index(w) for w in R]
hist=c.week_range(202627,202639); F=fcf.ff.F
months=[(i,f'{c.week_start(w).month}월') for i,w in enumerate(R) if c.week_start(w).day<=7]
fig,ax=plt.subplots(1,2,figsize=(13,4.3))
q=np.quantile(FL['REP']['ili'][:,fi],[.1,.5,.9],axis=0); x=np.arange(len(R)); xh=np.arange(-len(hist),0)+1
ax[0].fill_between(x,q[0],q[2],color='#2a6fdb',alpha=.2,label='가능성 높은 범위 (10명 중 8명)'); ax[0].plot(x,q[1],color='#2a6fdb',lw=3,label='가장 그럴듯한 예상')
ax[0].plot(xh,F.loc[hist,'ILI'],'ko-',ms=4,label='지금까지 실제')
ax[0].axhline(12.9,ls='--',color='#d1495b'); ax[0].text(30,15,'유행 기준선 12.9',color='#d1495b')
ax[0].set_title('독감 의심 환자 (병원 외래 1,000명 중 몇 명?)',fontsize=12); ax[0].legend(fontsize=9)
fh=FL['REP']['hosp'][:,fi]; ch=CV['out']['REP'][:,ci]; rng=np.random.default_rng(0); n=min(len(fh),len(ch)); tot=fh[rng.permutation(len(fh))[:n]]+ch[rng.permutation(len(ch))[:n]]
for arr,cl,lb in [(np.quantile(fh,[.1,.5,.9],axis=0),'#2a6fdb','독감 입원'),(np.quantile(ch,[.1,.5,.9],axis=0),'#7b3fbf','코로나19 입원'),(np.quantile(tot,[.1,.5,.9],axis=0),'#d1495b','합계')]:
    ax[1].plot(x,arr[1],color=cl,lw=3 if lb=='합계' else 2,label=lb)
ax[1].fill_between(x,np.quantile(tot,.1,axis=0),np.quantile(tot,.9,axis=0),color='#d1495b',alpha=.12)
C=c.load_covid(); ax[1].plot(xh,F.loc[hist,'ARI'].values+C.loc[hist,'ARI'].values,'ko-',ms=4,label='지금까지 실제(합계)')
ax[1].set_title('표본 병원 입원 환자 (주당)',fontsize=12); ax[1].legend(fontsize=9)
for a in ax:
    a.set_xticks([m[0] for m in months]); a.set_xticklabels([m[1] for m in months]); a.set_xlim(-len(hist),48); a.grid(alpha=.3)
    a.axvspan(1,5,color='orange',alpha=.12); a.text(1.2,a.get_ylim()[1]*0.92,'고비\n(10월 중순)',fontsize=9,color='#b06000')
fig.tight_layout(); fig.savefig('fig/simple.png',dpi=120)
