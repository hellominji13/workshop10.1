"""코로나19 후향 검증: 기점 2025-30까지 자료(변이 점유율도 기점까지)로 재적합 → 2026-26까지 52주 전망 → WIS."""
import numpy as np, pickle, common as c, fit_covid as fc
from scipy.optimize import differential_evolution, least_squares
from valid_forecast import wis, QL
O=202530; fc.SEAS='HARM'
Wfit=c.week_range(202401,O); fc.W=Wfit; fc.OBS=fc.D.loc[Wfit,'ARI'].values.astype(float)
for f in fc.FAM:
    for yw in list(fc.DV[f]):
        if yw>O: fc.DV[f][yw]=0.0          # 기점 이후 점유율 미사용
vs,hr=0.584,0.293
def resid(x,vs,hr):
    h,_,_=fc.run(x,vs,hr,weeks=Wfit); d=dict(zip(fc.P,x))
    return np.r_[np.log(h+10)-np.log(fc.OBS+10),(d['hrep']-0.8)/0.2,(d['wane']-240)/90]
obj=lambda x: float(np.sum(resid(x,vs,hr)**2))
de=differential_evolution(obj,list(zip(fc.LB,fc.UB)),seed=1,maxiter=100,popsize=12,tol=1e-8,polish=False)
sol=least_squares(resid,de.x,bounds=(fc.LB,fc.UB),args=(vs,hr),x_scale='jac',max_nfev=200)
J=sol.jac; s2=(sol.fun**2).sum()/(len(sol.fun)-len(sol.x)); cov=np.linalg.pinv(J.T@J)*s2
ALL=c.week_range(202401,202626); FW=c.week_range(c.next_week(O),202626); fi=[ALL.index(w) for w in FW]
y=fc.D.loc[FW,'ARI'].values.astype(float); rng=np.random.default_rng(3); H=[]
E=np.array([sol.x[fc.P.index('e_'+k)] for k in fc.FAM])
for j in range(400):
    x=np.clip(rng.multivariate_normal(sol.x,cov),fc.LB,fc.UB); extra={}
    for _ in range(rng.poisson(6/(26/12)*len(FW)/52)):   # 기점 이후 변이 교체는 대표 전망과 같은 포아송 가정
        ctr=int(rng.integers(fi[0]+2,len(ALL))); p=1/(1+np.exp(-(np.arange(len(ALL))-ctr)/3.0)); d=np.diff(np.r_[0,p]); e=rng.choice(E)
        for t,yw in enumerate(ALL):
            if d[t]>1e-4: extra[yw]=1-(1-extra.get(yw,0))*(1-e*d[t])
    u=np.zeros(len(ALL))
    for t in range(fi[0],len(ALL)): u[t]=0.8*u[t-1]+rng.normal(0,0.05)
    h,_,_=fc.run(x,vs,hr,weeks=ALL,qmult=np.exp(u),extra=extra); H.append(h[fi]*np.exp(rng.normal(0,0.12,len(FW))))
H=np.array(H); q=np.quantile(H,QL,axis=0); S=np.mean([wis(q[:,k],y[k]) for k in range(len(FW))])
hist=fc.D.loc[Wfit,'ARI'].values.astype(float); qb=np.zeros((7,len(FW)))
for h in range(1,len(FW)+1):
    dd=hist[h:]-hist[:-h]; dd=np.r_[dd,-dd]; qb[:,h-1]=np.maximum(hist[-1]+np.quantile(dd,QL),0)
SB=np.mean([wis(qb[:,k],y[k]) for k in range(len(FW))])
print('COVID valid WIS',round(S,1),'base',round(SB,1),'cov95',np.mean((y>=q[0])&(y<=q[6])).round(2),'cov50',np.mean((y>=q[2])&(y<=q[4])).round(2),'peak obs',y.max(),FW[int(y.argmax())],'pred',np.quantile(H.max(1),[.1,.5,.9]).round(0))
pickle.dump(dict(FW=FW,q=q,y=y,wis=S,base=SB),open('covid_valid.pkl','wb'))
