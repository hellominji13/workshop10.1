"""정책(접종) 시나리오: S0 경로로 반영. 같은 난수(짝지은 비교)로 대표 전망 대비 차이."""
import numpy as np, pickle, flu, forecast_flu as f
base=flu.COV.copy()
P={'P0 접종 없음':dict(cov=base*0),
   'P1 예년 일정(42주 시작)':dict(vstart=42),
   'P2 실제 일정(39주, 앞당김)':dict(vstart=39),
   'P3 13~18세 국가접종 확대(70%)':dict(cov=np.r_[base[:2],0.70,base[3:]]),
   'P4 19~64세 접종률 +15%p':dict(cov=base+np.array([0,0,0,.15,.15,0]))}
fi=[f.ALLW.index(w) for w in f.REPORT]
res={}
for k,kw in P.items():
    o=f.run('REP',seed=99,**kw)
    x=o['ili'][:,fi]; h=o['hosp'][:,fi]
    res[k]=dict(pk=np.median(x.max(1)),cum=np.median(x.sum(1)),hpk=np.median(h.max(1)),hcum=np.median(h.sum(1)),attack=np.median(o['attack'],0),
               d_hcum=None)
    res[k]['raw_h']=h.sum(1); res[k]['raw_ili']=x.sum(1)
ref=res['P2 실제 일정(39주, 앞당김)']
for k,v in res.items():
    v['d_hcum_pct']=np.median((v['raw_h']-ref['raw_h'])/ref['raw_h'])*100
    v['d_ili_pct']=np.median((v['raw_ili']-ref['raw_ili'])/ref['raw_ili'])*100
    print(f"{k:28s} ILI정점 {v['pk']:.1f}  ILI누적 {v['cum']:.0f}  입원정점 {v['hpk']:.0f}  입원누적 {v['hcum']:.0f}  Δ입원 {v['d_hcum_pct']:+.1f}%  ΔILI {v['d_ili_pct']:+.1f}%  감염률(연령) {np.round(v['attack']*100,1)}")
pickle.dump({k:{kk:vv for kk,vv in v.items() if not kk.startswith('raw')} for k,v in res.items()},open('policy_runs.pkl','wb'))
