import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c
plt.rcParams['font.family']='Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus']=False
R=pickle.load(open('valid_results_0.05.pkl','rb'))
fig,ax=plt.subplots(1,4,figsize=(19,4.6),gridspec_kw=dict(width_ratios=[1,1,1,0.8]))
NAVY='#1f4e79'
for k,T in enumerate([2023,2024,2025]):
    r=R[T]; W=r['W']; iO=r['iO']; x=np.arange(len(W)); fx=x[iO+1:]
    q=r['q']; a=ax[k]
    a.fill_between(fx,q[0],q[6],color=NAVY,alpha=.13,label='95%'); a.fill_between(fx,q[1],q[5],color=NAVY,alpha=.25,label='80%')
    a.plot(fx,q[3],color=NAVY,lw=2.2,label='전망 중앙값')
    F=__import__('fit_flu').F
    a.plot(x[:iO+1],F.loc[W[:iO+1],'ILI'],'o',color='#c0392b',ms=4,label='기점까지 관측(입력)')
    a.plot(fx,r['y'],'ko',ms=3,label='실제 관측(미사용)')
    a.axvline(iO,color='gray',ls=':',lw=1)
    pk=r['pk_q']
    a.set_title(f"{T}-{(T+1)%100:02d} 절기: 38주 기점 전망\n정점 실제 {r['pk_obs']:.0f} / 전망 {pk[1]:.0f} [{pk[0]:.0f}–{pk[2]:.0f}] · WIS {r['wis'].mean():.2f}",fontsize=11,loc='left')
    tk=[i for i,w in enumerate(W) if w%100 in (45,1,10,19,28)]
    a.set_xticks(tk); a.set_xticklabels([f"{c.week_start(W[i]).year%100}.{c.week_start(W[i]).month:02d}" for i in tk])
    a.spines[['top','right']].set_visible(False)
    if k==0: a.set_ylabel('ILI (외래 1,000명당)'); a.legend(fontsize=8,frameon=False)
mb=np.mean([R[T]['wis_base'].mean() for T in R]); mo=np.mean([R[T]['wis'].mean() for T in R])
labs=['기준모형\n(부록 B)','β 장부\n(기존, κ 보정 최적)','연령·공통접촉\nSEIR (본 모형)']; vals=[mb,6.14,mo]
b=ax[3].bar(range(3),vals,color=['#95a5a6','#95a5a6',NAVY])
for i,v in enumerate(vals): ax[3].text(i,v+0.1,f'{v:.2f}',ha='center')
ax[3].set_xticks(range(3)); ax[3].set_xticklabels(labs,fontsize=9); ax[3].set_ylabel('평균 WIS (3개 절기, 낮을수록 좋음)')
ax[3].set_title('후향 검증 WIS (기점 38주 → 절기 끝)',fontsize=11,loc='left'); ax[3].spines[['top','right']].set_visible(False); ax[3].set_ylim(0,max(vals)*1.2)
fig.tight_layout(); fig.savefig('fig/validation.png',dpi=120)
for T in R: print(T, R[T]['wis'].mean().round(2), R[T]['wis_base'].mean().round(2), R[T]['cover50'].round(2), R[T]['cover95'].round(2))
