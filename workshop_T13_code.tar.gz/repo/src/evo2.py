"""문제 3-가: 바이러스 관점의 침입 적합도(invasion fitness).
변이를 집단수준 형질 2개로만 정의한다(분자·유전 수준은 다루지 않음).
  ε : 유입 시점에 '이미 면역을 가진 사람' 중 이 변이에는 다시 감염될 수 있게 되는 비율
  τ : 현재 유행 중인 아형 대비 전파력 배수
비용(trade-off): 면역 회피가 커질수록 전파력이 낮아진다고 가정, τ ≤ 1 − k·ε^p
적합도: 유입 후 절기 말까지 그 변이의 누적 감염자 수
두 가지 상황을 비교한다.
  (A) 2026-27 절기 중 유입  — 겨울이 진행되며 면역이 쌓이는 상황
  (B) 2027-28 절기 시작 시 유입 — 이번 겨울 대유행으로 면역이 높아진 뒤
"""
import numpy as np, pickle, common as c, flu, fit_flu as ff, forecast_flu as fcf
POST=pickle.load(open('now.pkl','rb')); G=dict(zip(ff.G,np.median(POST['GV'],0))); SIG=ff.sigma(G)
sH1=np.median(POST['s']); mH1=np.median(POST['m']); lI=np.median(POST['lI'])
QB=G['R0']/flu.R0*mH1
W1=c.week_range(202640,202735); W2=c.week_range(202736,202835)
def resident_path():
    """현재 A(H1N1)pdm09 단독 경로. 각 주의 상태를 저장."""
    S0=np.zeros((3,6)); I0=np.zeros((3,6)); S0[0]=np.minimum(sH1*SIG[0],0.995); I0[0]=np.exp(lI)
    st=(S0,I0*flu.LAT/flu.INF,I0,np.zeros((3,6))); states=[]; 
    for t,yw in enumerate(W1+W2):
        states.append(tuple(x.copy() for x in st))
        qm=[np.array([QB,0.,0.])]
        _,st=flu.simulate([yw],None,None,G['theta'],G['vac_school'],G['hol_red'],qmult=qm,state=st)
    return states
STATES=resident_path(); ALL=W1+W2
def invade(eps,tau,wk):
    """wk 주에 변이를 유입. 그 시점 면역 보유자의 ε만큼이 변이에 감수성이 된다."""
    i=ALL.index(wk); S,E,I,V=(x.copy() for x in STATES[i])
    imm=np.clip(1-S[0]-E[0]-I[0],0,1)                  # 현재 아형에 대한 면역·회복 인구
    S[1]=np.clip(S[0]+eps*imm,0,0.995); E[1]=0; I[1]=1e-5
    qm=[np.array([QB,QB*tau,0.]) for _ in ALL[i:]]
    inc,_=flu.simulate(ALL[i:],None,None,G['theta'],G['vac_school'],G['hol_red'],qmult=qm,state=(S,E,I,V))
    nW=min(len(inc),52)
    return float((inc[:nW,1]*c.N).sum()), float((inc[:nW,0]*c.N).sum()), float(S[1].mean())
if __name__=='__main__':
    EPS=np.linspace(0,0.9,19); TAU=np.linspace(0.6,1.4,17)
    for lbl,wk in [('A_2026절기중_46주',202646),('B_2027절기초_2027-40',202740)]:
        Z=np.zeros((len(EPS),len(TAU)))
        for i,e in enumerate(EPS):
            for j,t_ in enumerate(TAU): Z[i,j]=invade(e,t_,wk)[0]
        pickle.dump(dict(EPS=EPS,TAU=TAU,Z=Z,wk=wk),open(f'evo_grid_{lbl[0]}.pkl','wb'))
        print(lbl,'min/max(백만)',round(Z.min()/1e6,2),round(Z.max()/1e6,2),flush=True)
    # 유입 시점별 (ε=0.5, τ=0.9)
    WKS=[c.next_week(202640,k) for k in range(0,96,2)]
    tcur=[invade(0.0,1.0,w)[0] for w in WKS]; tesc=[invade(0.5,0.9,w)[0] for w in WKS]
    pickle.dump(dict(WKS=WKS,no_escape=tcur,escape=tesc),open('evo_timing.pkl','wb'))
    print('timing done',flush=True)
