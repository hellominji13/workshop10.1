import common as c, numpy as np, pickle
F=c.load_flu(); ok=F[((F.index<202010)|(F.index>=202236))&(F.index<202626)]
pl=ok.ILI*ok.pos/100; t=2*np.pi*(ok.index%100)/52.18
X=np.c_[pl,np.ones(len(ok)),np.cos(t),np.sin(t),np.cos(2*t),np.sin(2*t)]
b=np.linalg.lstsq(X,ok.ILI.values,rcond=None)[0]; base=X[:,1:]@b[1:]
an=np.log(np.clip(ok.ILI.values-b[0]*pl,0.5,None))-np.log(np.clip(base,0.5,None))
rho=np.corrcoef(an[1:],an[:-1])[0,1]; sd=np.std(an[1:]-rho*an[:-1])
pickle.dump(dict(b=b,rho=rho,sd=sd),open('bg.pkl','wb')); print(b,rho,sd)
