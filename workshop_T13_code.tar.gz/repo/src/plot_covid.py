import numpy as np, pickle, sys, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, fit_covid as fc
plt.rcParams['font.family']='Noto Sans CJK JP'
fig,axs=plt.subplots(len(sys.argv[1:]),1,figsize=(13,3.8*len(sys.argv[1:])),squeeze=False); axs=axs[:,0]
for ax,nm in zip(axs,sys.argv[1:]):
    f=pickle.load(open(nm,'rb')); fc.SEAS=f['seas']; h,inc,st=fc.run(f['x'],f['vs'],f['hr'])
    x=np.arange(len(fc.W))
    ax.plot(x,fc.OBS,'o',ms=3,color='k',label='관측 (ARI 코로나19 입원)'); ax.plot(x,h,'-',color='#7b3fbf',lw=2,label='모형')
    ax.axvline(fc.W.index(202436),color='r',ls='--',lw=1); ax.text(fc.W.index(202436)+0.5,1200,'4급 전환\n(2024.8.31)',color='r',fontsize=8)
    for f_,ls in fc.FAM.items():
        dv=np.array([fc.DV[f_].get(w,0) for w in fc.W]); 
        if dv.max()>0: i=int(np.argmax(dv)); ax.text(i,1350,f_,fontsize=8,rotation=90,color='gray'); ax.axvline(i,ls=':',color='gray')
    R2=1-((fc.OBS-h)**2).sum()/((fc.OBS-fc.OBS.mean())**2).sum()
    R2l=1-((np.log(fc.OBS+10)-np.log(h+10))**2).sum()/((np.log(fc.OBS+10)-np.log(fc.OBS+10).mean())**2).sum()
    ax.set_title(f'코로나19 입원 적합: R²={R2:.2f}, log R²={R2l:.2f} (점선=계통군 점유율 증가 최대 시점)'); tk=x[::13]; ax.set_xticks(tk); ax.set_xticklabels([str(fc.W[i]) for i in tk]); ax.legend()
fig.tight_layout(); fig.savefig('fig/covid_fit.png',dpi=110)
