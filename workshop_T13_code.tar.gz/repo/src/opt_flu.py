"""문제 3: 비용 최소화 접종 전략 — 차분진화(differential evolution, 진화 알고리즘).
결정변수: 연령별 접종률 6개 + 접종 시작 주.  제약: 총 접종 수 ≤ 현행(같은 백신 물량).
비용 = 백신비 + 외래 진료비 + 입원 진료비  (2024-25 건강보험 청구 중앙값, 연례보고서)"""
import numpy as np, pickle, common as c, flu, fit_flu as ff, hosp_flu as hf, forecast_flu as fcf
from scipy.optimize import differential_evolution
C_VAC=25000; C_OUT=23300; C_HOSP=1161365; NAT_PER_SENT=144424/8640
post=pickle.load(open('now.pkl','rb')); HP=pickle.load(open('hosp_flu.pkl','rb'))
G=dict(zip(ff.G,np.median(post['GV'],0))); sig=ff.sigma(G)
SH=fcf.SH; W=fcf.ALLW
S0=np.zeros((3,6)); S0[0]=np.minimum(np.median(post['s'])*sig[0],0.995)
S0[1]=np.minimum(np.median(SH[:,1])*sig[1],0.995); S0[2]=np.minimum(np.median(SH[:,2])*sig[2],0.995)
I0=np.zeros((3,6)); I0[0]=np.exp(np.median(post['lI']))
seeds=[None]*len(W)
for k,on in ((1,int(np.median(fcf.ON['H3']))-2),(2,int(np.median(fcf.ON['B']))-2)):
    t=W.index(fcf.wk_from36(on)); e=np.zeros((3,6)); e[k]=1e-5; seeds[t]=e if seeds[t] is None else seeds[t]+e
QM=np.full(len(W),G['R0']/flu.R0*np.median(post['m']))
DOSES0=(flu.COV*c.N).sum()
def evaluate(cov,start):
    inc,_=flu.simulate(W,S0,I0,G['theta'],G['vac_school'],G['hol_red'],cov=cov,vstart=int(round(start)),qmult=QM,seed_add=seeds)
    i40=W.index(202640); inc=inc[i40:]
    ma=(inc.sum((0,1))*c.N)*flu.P_SYM*flu.P_CONS
    hosp=HP['eta']*hf.hosp_index(inc).sum()*NAT_PER_SENT
    doses=(cov*c.N).sum()
    cost=C_VAC*doses+C_OUT*ma.sum()+C_HOSP*hosp
    return dict(cost=cost,vac=C_VAC*doses,out=C_OUT*ma.sum(),hosp_cost=C_HOSP*hosp,hosp=hosp,ma=ma.sum(),doses=doses,inf_age=inc.sum((0,1)))
def obj(z,mode='same'):
    cov=np.clip(z[:6],0,0.9)
    if mode=='same':      # 같은 물량: 총 접종 수를 현행과 같게 맞춘 뒤(비례 조정) 의료비(외래+입원) 최소화
        d=(cov*c.N).sum(); cov=np.clip(cov*DOSES0/max(d,1),0,0.9)
        r=evaluate(cov,z[6]); pen=abs((cov*c.N).sum()-DOSES0)/DOSES0*1e4
        return (r['out']+r['hosp_cost'])/1e8+pen
    r=evaluate(cov,z[6]); return r['cost']/1e8
if __name__=='__main__':
    cur=evaluate(flu.COV,39); late=evaluate(flu.COV,42)
    b=[(0,0.9)]*6+[(36,46)]
    hist=[]
    r1=differential_evolution(obj,b,args=('same',),seed=1,maxiter=80,popsize=12,tol=1e-9,polish=False,callback=lambda xk,convergence=None: hist.append(obj(xk,'same')))
    c1=np.clip(r1.x[:6],0,.9); c1=np.clip(c1*DOSES0/(c1*c.N).sum(),0,.9); r1.x[:6]=c1
    r2=differential_evolution(obj,b,args=('free',),seed=2,maxiter=60,popsize=12,tol=1e-9,polish=False)
    o1=evaluate(c1,r1.x[6]); o2=evaluate(np.clip(r2.x[:6],0,.9),r2.x[6])
    out=dict(cur=cur,late=late,opt_same=dict(x=r1.x,**o1),opt_free=dict(x=r2.x,**o2),DOSES0=DOSES0,hist1=hist)
    pickle.dump(out,open('opt_results.pkl','wb'))
    for k in ['cur','late','opt_same','opt_free']:
        v=out[k]; print(k,'cost(억)',round(v['cost']/1e8),'vac',round(v['vac']/1e8),'out',round(v['out']/1e8),'hospcost',round(v['hosp_cost']/1e8),'hosp',round(v['hosp']),'doses(만)',round(v['doses']/1e4), v.get('x',np.r_[flu.COV,39]).round(2))
