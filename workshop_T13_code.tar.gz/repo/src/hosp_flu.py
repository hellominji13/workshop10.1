"""인플루엔자 입원(ARI 표본감시) = η · Σ_a r_a · N_a · 주간감염_a
r_a: 연령별 감염당 입원 상대위험. 연례보고서(2024-25) 표본감시 입원의 연령 분포
(0세 2.4%+1-6세 7.4%, 7-12 9.2, 13-18 4.2, 19-49 9.1, 50-64 15.3, 65+ 52.4)를
같은 절기 모형의 연령별 감염 분포로 나눠 산출 → 19-49세=1로 정규화."""
import numpy as np, pickle, os, common as c
HSHARE=np.array([9.8,9.2,4.2,9.1,15.3,52.4])/100
_P='hosp_flu.pkl'
R_REL=pickle.load(open(_P,'rb'))['r'] if os.path.exists(_P) and 'r' in pickle.load(open(_P,'rb')) else np.ones(6)
def hosp_index(inc, r=None):
    r=R_REL if r is None else r
    return (inc.sum(1)*c.N*r).sum(1)
if __name__=='__main__':
    import fit_flu as ff
    fit=pickle.load(open('flu_fit.pkl','rb')); res,keep=ff.resid(fit['x'],True)
    w,inc,tot,age=keep[6]                       # 2024-25
    infa=inc.sum((0,1))*c.N; r=HSHARE/(infa/infa.sum()); r=r/r[3]
    X=[];Y=[];S=[]
    for i in (6,7):
        w,inc,tot,age=keep[i]; X+=list(hosp_index(inc,r)); Y+=list(ff.F.loc[w,'ARI'].values); S+=[i]*len(w)
    X=np.array(X);Y=np.array(Y); eta=Y.sum()/X.sum(); mm=(Y>50)&(eta*X>20)
    sd=np.std(np.log(Y[mm])-np.log(eta*X[mm]))
    print('r',r.round(2),'eta',eta,'sd',sd)
    # 의료이용 발생 검증: 모형 2024-25 의료이용 건수 = Σ 감염 × P_SYM × P_CONS  vs 건강보험 3,866,190건
    import flu
    print('model medically-attended 2024-25',(keep[6][1].sum((0,1))*c.N).sum()*flu.P_SYM*flu.P_CONS,'NHIS 3,866,190')
    pickle.dump(dict(eta=eta,sd=sd,r=r),open(_P,'wb'))
