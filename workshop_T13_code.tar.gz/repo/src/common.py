"""공통 모듈: 주차 달력, 인구, 공통 접촉행렬(4층), 학교·명절 달력, 습도, 자료 로드."""
import numpy as np, pandas as pd, datetime as dt
import os
D=os.environ.get('DATA_DIR', os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),'data')) + os.sep
AGES=['0-6','7-12','13-18','19-49','50-64','65+']; NA=6
# 2026년 주민등록인구 근사(KOSIS 연령별 주민등록인구 2025.12 + 출생아 수로 0-18세 보정), 단위 명
N=np.array([1.75e6,2.27e6,2.77e6,20.9e6,12.6e6,10.8e6])

# ---------- 공통 접촉행렬 (일평균 접촉 수, 행=응답자 연령 i, 열=접촉자 연령 j) ----------
# 구조: Prem et al. 2017/2021 한국 합성행렬의 4개 장소층(가정·학교·직장·기타)을 6개 연령군으로 축약한 형태.
# 장소별 평균 접촉 수는 POLYMOD(Mossong 2008)와 한국 접촉조사(2023-24, BMC Infect Dis 2025)의 범위에 맞춤.
# 상호성(N_i C_ij = N_j C_ji)을 강제해 대칭화.
_home=np.array([[1.0,0.6,0.3,2.0,0.4,0.4],[0.6,0.9,0.5,2.0,0.4,0.3],[0.3,0.5,0.9,1.8,0.6,0.3],
                [0,0,0,1.3,0.4,0.2],[0,0,0,0,0.9,0.3],[0,0,0,0,0,0.9]])
_school=np.array([[4.5,0.2,0,0.6,0.1,0],[0.2,9.0,0.4,1.0,0.2,0],[0,0.4,8.5,1.0,0.2,0],
                  [0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0]])
_work=np.array([[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0.1,0.3,0.1,0],
                [0,0,0,4.5,1.6,0.2],[0,0,0,0,2.2,0.3],[0,0,0,0,0,0.4]])
_other=np.array([[0.7,0.3,0.1,1.2,0.3,0.4],[0.3,1.6,0.4,1.2,0.4,0.3],[0.1,0.4,2.0,1.5,0.5,0.3],
                 [0,0,0,3.0,1.2,0.5],[0,0,0,0,1.8,0.7],[0,0,0,0,0,1.8]])
def _recip(U):
    """위삼각에 주어진 값(행 기준)과 그 반대방향을 인구로 상호성 보정해 완성."""
    M=np.zeros((NA,NA))
    for i in range(NA):
        for j in range(NA):
            if j>=i:
                # 전체 접촉쌍 수 T_ij = C_ij N_i 를 기준, 아래삼각은 T/N_j
                M[i,j]=U[i,j]
    T=M*N[:,None]
    T=np.triu(T)+np.triu(T,1).T
    return T/N[:,None]
LAYERS={k:_recip(v) for k,v in dict(home=_home,school=_school,work=_work,other=_other).items()}
import os as _os
LAYERS['school']=LAYERS['school']*float(_os.environ.get('SCHOOL_SCALE','1.0'))   # 민감도 분석용

# ---------- 주차 (질병관리청 = MMWR 규칙: 일~토, 1주는 새해 날이 4일 이상인 첫 주) ----------
def _w1start(y):
    j=dt.date(y,1,1); wd=(j.weekday()+1)%7     # 일=0
    s=j-dt.timedelta(days=wd)
    return s if wd<=4 else s+dt.timedelta(days=7)   # 1월 1일이 일~목이면 그 주가 1주 (2026-53 = 12.27~1.2 확인)
def week_start(yw):
    y,w=divmod(int(yw),100); return _w1start(y)+dt.timedelta(days=7*(w-1))
def yw_of(d):
    y=d.year
    for yy in (y+1,y,y-1):
        s=_w1start(yy)
        if d>=s: return yy*100+(d-s).days//7+1
def next_week(yw,k=1):
    return yw_of(week_start(yw)+dt.timedelta(days=7*k))
def week_range(a,b):
    out=[a]
    while out[-1]!=b: out.append(next_week(out[-1]))
    return out

# ---------- 명절(설·추석, 연휴가 낀 주) ----------
_HOL=['2016-02-08','2016-09-15','2017-01-28','2017-10-04','2018-02-16','2018-09-24','2019-02-05','2019-09-13',
      '2020-01-25','2022-02-01','2022-09-10','2023-01-22','2023-09-29','2024-02-10','2024-09-17','2025-01-29','2025-10-06',
      '2026-02-17','2026-09-25','2027-02-07','2027-09-15']
HOLIDAY={yw_of(dt.date.fromisoformat(s)) for s in _HOL}
# ---------- 학교 달력(한국 초중고 학사일정 일반형) ----------
def school_on(yw):
    w=yw%100
    if w>=52 or w<=9: return 0.0          # 겨울방학 + 학년말(1~2월)
    if 30<=w<=33: return 0.0              # 여름방학(7월 말~8월 중순)
    return 1.0

def contact(yw,vac_school,hol_red):
    """시점별 공통 접촉행렬 C(t). vac_school: 방학 중 학교층 잔존율, hol_red: 명절 주 학교·직장 접촉 잔존율"""
    sch=school_on(yw); s=sch+(1-sch)*vac_school
    wk=1.0
    if yw in HOLIDAY: s*=hol_red; wk=hol_red
    return LAYERS['home']+s*LAYERS['school']+wk*LAYERS['work']+LAYERS['other']

# ---------- 습도 ----------
def load_ah():
    a=pd.read_csv(D+'ah.csv'); a.columns=['date','stn','name','T','RH','AH']
    a['date']=pd.to_datetime(a.date); a['yw']=[yw_of(d.date()) for d in a.date]
    w=a.groupby('yw').AH.mean()
    clim=w.groupby(w.index%100).mean()
    return w,clim
AH,AHCLIM=load_ah()
def ah_at(yw):
    return AH.get(yw, AHCLIM.get(yw%100, AHCLIM.mean()))

# ---------- 자료 ----------
def load_flu():
    d=pd.read_excel(D+'flu2_subtype.xlsx'); d.columns=['y','w','yw','ARI','ILI','pos','H1','H3','B','s']
    d=d[['yw','ARI','ILI','pos','H1','H3','B']].copy()
    for k in ['H1','H3','B']: d[k+'p']=d.ILI*d[k]/100.0      # 아형별 ILI+ (Goldstein 2011)
    d['bg']=d.ILI*(1-d.pos/100)                                # 비인플루엔자 ILI
    return d.set_index('yw')
def load_covid():
    c=pd.read_excel(D+'covid2.xlsx'); c.columns=['y','w','yw','ARI','SARI']
    return c[['yw','ARI','SARI']].set_index('yw')
def load_age():
    a=pd.read_excel(D+'ili10.xlsx'); a=a.rename(columns={'절기':'season','구분':'age'})
    return a
