import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, flu, fit_flu as ff, forecast_flu as fcf
plt.rcParams['font.family']='Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus']=False
# 1) 접촉행렬 4층
fig,ax=plt.subplots(1,5,figsize=(20,4))
for k,(nm,M) in enumerate(list(c.LAYERS.items())+[('합계(학기 중)',c.contact(202645,1,1))]):
    im=ax[k].imshow(M,cmap='YlOrRd',vmin=0,vmax=10); ax[k].set_xticks(range(6)); ax[k].set_xticklabels(c.AGES,rotation=45,fontsize=8); ax[k].set_yticks(range(6)); ax[k].set_yticklabels(c.AGES,fontsize=8)
    ax[k].set_title({'home':'가정','school':'학교','work':'직장','other':'기타'}.get(nm,nm))
    for i in range(6):
        for j in range(6): ax[k].text(j,i,f'{M[i,j]:.1f}',ha='center',va='center',fontsize=7)
fig.suptitle('공통 접촉행렬 C(t) = 가정 + 학교×s(t) + 직장×w(t) + 기타   (행=본인 연령, 열=접촉 상대, 하루 평균 접촉 수)'); fig.tight_layout(); fig.savefig('fig/contact.png',dpi=110)
# 2) 결합 프로파일
r=np.array(pickle.load(open('joint.pkl','rb'))); V=sorted(set(r[:,0])); H=sorted(set(r[:,1]))
fig,ax=plt.subplots(1,3,figsize=(15,4))
for k,(col,tt) in enumerate([(2,'인플루엔자'),(3,'코로나19'),(None,'합계 (공동 추정)')]):
    z=np.zeros((len(V),len(H)))
    for row in r:
        val=row[2]+row[3] if col is None else row[col]; z[V.index(row[0]),H.index(row[1])]=val
    z=z-z.max(); im=ax[k].imshow(np.maximum(z,-30),origin='lower',cmap='viridis',aspect='auto')
    ax[k].set_xticks(range(len(H))); ax[k].set_xticklabels(H); ax[k].set_yticks(range(len(V))); ax[k].set_yticklabels(V)
    ax[k].set_xlabel('명절 주 학교·직장 접촉 잔존율 h'); ax[k].set_ylabel('방학 중 학교 접촉 잔존율 v'); ax[k].set_title(f'{tt}: 로그우도 (최대 대비)')
    i,j=np.unravel_index(z.argmax(),z.shape); ax[k].plot(j,i,'r*',ms=15)
    for a in range(len(V)):
        for b in range(len(H)): ax[k].text(b,a,f'{z[a,b]:.0f}',ha='center',va='center',fontsize=7,color='w')
fig.tight_layout(); fig.savefig('fig/joint_contact.png',dpi=110)
# 3) 정책
P=pickle.load(open('policy_runs.pkl','rb')); ks=list(P)
fig,ax=plt.subplots(1,2,figsize=(14,4))
ax[0].barh(range(len(ks)),[P[k]['hcum'] for k in ks],color=['#999','#e0a040','#2a6fdb','#2a9d5c','#7b3fbf']); ax[0].set_yticks(range(len(ks))); ax[0].set_yticklabels(ks); ax[0].invert_yaxis(); ax[0].set_title('절기 누적 인플루엔자 입원 (표본감시, 중앙값)')
for i,k in enumerate(ks): ax[0].text(P[k]['hcum'],i,f" {P[k]['hcum']:,.0f} ({P[k]['d_hcum_pct']:+.0f}%)",va='center',fontsize=9)
ax[0].set_xlim(0,max(P[k]['hcum'] for k in ks)*1.35)
w=0.2; base0=P[ks[0]]['attack']
for i,k in enumerate(ks[1:]): ax[1].bar(np.arange(6)+i*w,(1-P[k]['attack']/base0)*100,w,label=k,color=['#e0a040','#2a6fdb','#2a9d5c','#7b3fbf'][i])
ax[1].set_xticks(np.arange(6)+0.3); ax[1].set_xticklabels(c.AGES); ax[1].set_ylabel('%'); ax[1].set_title('연령별 감염 감소율 (접종 없음 대비, %)'); ax[1].legend(fontsize=8)
fig.tight_layout(); fig.savefig('fig/policy.png',dpi=110)
# 4) 현재 절기 nowcast 적합 (H1 ILI+)
post=pickle.load(open('now.pkl','rb')); import flu_now as fn
W=c.week_range(202626,202639); sims=[]
for j in range(0,len(post['s']),5):
    inc,st,g=fn.sim_cur(post['GV'][j],post['s'][j],np.exp(post['lI'][j]),post['m'][j],W)
    tot,_=flu.obs_ili(inc,np.exp(g['logkappa'])); hol=np.array([g['hrep'] if yw in c.HOLIDAY else 1 for yw in W]); sims.append(tot[:,0]*hol)
sims=np.array(sims); q=np.quantile(sims,[.05,.5,.95],axis=0)
fig,ax=plt.subplots(figsize=(7,4)); x=np.arange(len(W))
ax.fill_between(x,q[0],q[2],alpha=.3,color='#2a6fdb'); ax.plot(x,q[1],color='#2a6fdb',lw=2,label='모형 (nowcast 사후, 90%)'); ax.plot(x,ff.F.loc[W,'H1p'],'ko',label='관측 H1 ILI+')
ax.set_xticks(x[::2]); ax.set_xticklabels([str(w%100)+'주' for w in W[::2]]); ax.legend(); ax.set_title('2026 여름 H1 파동 nowcast (26~39주)')
fig.tight_layout(); fig.savefig('fig/nowcast_h1.png',dpi=110)
# 5) Q-a 입원 합계
FL=pickle.load(open('flu_scen.pkl','rb')); CV=pickle.load(open('covid_scen.pkl','rb'))
fi=[fcf.ALLW.index(w) for w in fcf.REPORT]; ci=[CV['ALLW'].index(w) for w in fcf.REPORT]
rng=np.random.default_rng(0); fh=FL['REP']['hosp'][:,fi]; ch=CV['out']['REP'][:,ci]; n=min(len(fh),len(ch))
fh=fh[rng.permutation(len(fh))[:n]]; ch=ch[rng.permutation(len(ch))[:n]]; tot=fh+ch
fig,ax=plt.subplots(figsize=(10,4)); x=np.arange(49)
for arr,cl,lb in [(fh,'#2a6fdb','인플루엔자 입원'),(ch,'#7b3fbf','코로나19 입원'),(tot,'#d1495b','합계')]:
    q=np.quantile(arr,[.1,.5,.9],axis=0); ax.fill_between(x,q[0],q[2],color=cl,alpha=.15); ax.plot(x,q[1],color=cl,lw=2,label=lb)
tk=[0,4,9,13,17,22,26,30,35,39,43,48]; ax.set_xticks(tk); ax.set_xticklabels([f'{fcf.REPORT[i]//100%100}-{fcf.REPORT[i]%100:02d}' for i in tk],fontsize=8)
ax.legend(); ax.set_title('표본감시 입원환자 (주) — 대표 전망 중앙값과 80% 구간'); fig.tight_layout(); fig.savefig('fig/hosp_combined.png',dpi=110)
print('ok')
