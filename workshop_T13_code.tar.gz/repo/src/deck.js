const pptxgen = require('pptxgenjs');
const pres = new pptxgen(); pres.layout='LAYOUT_16x9';
const F='/home/claude/model/fig/'; const FONT='Malgun Gothic';
const NAVY='1E2761', ICE='CADCFC', CORAL='F96167', TEAL='028090', INK='1D1D1F', GRAY='6B7280', LIGHT='F3F6FC';
const T=(s,txt,o)=>s.addText(txt,Object.assign({isTextBox:true,fontFace:FONT,color:INK,margin:0},o));
function title(s,t,sub){ T(s,t,{x:0.45,y:0.28,w:9.1,h:0.5,fontSize:24,bold:true,color:NAVY}); if(sub) T(s,sub,{x:0.45,y:0.78,w:9.1,h:0.3,fontSize:11,color:GRAY}); }
function card(s,x,y,w,h,head,body,col){ s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y,w,h,fill:{color:LIGHT},line:{color:'DDE3F0',width:0.75},rectRadius:0.08});
  s.addShape(pres.shapes.OVAL,{x:x+0.15,y:y+0.15,w:0.28,h:0.28,fill:{color:col||TEAL}});
  T(s,head,{x:x+0.52,y:y+0.12,w:w-0.65,h:0.34,fontSize:12,bold:true,color:NAVY,valign:'middle'});
  T(s,body,{x:x+0.15,y:y+0.52,w:w-0.3,h:h-0.6,fontSize:10,color:INK,valign:'top',paraSpaceAfter:3}); }
function stat(s,x,y,w,num,lab,col){ T(s,num,{x,y,w,h:0.55,fontSize:28,bold:true,color:col||CORAL}); T(s,lab,{x,y:y+0.55,w,h:0.4,fontSize:9.5,color:GRAY}); }
const foot=(s,n)=>T(s,`T13 · 2026 예측네트워크 추계 워크숍 · ${n}`,{x:0.45,y:5.3,w:9.1,h:0.2,fontSize:8,color:'9CA3AF'});

// 1 표지
let s=pres.addSlide(); s.background={color:NAVY};
T(s,'2026 예측네트워크 추계 워크숍 · 팀 T13 · 인수인계',{x:0.6,y:0.5,w:8.8,h:0.3,fontSize:12,color:ICE});
T(s,'같은 사람, 같은 만남, 다른 바이러스',{x:0.6,y:1.0,w:8.8,h:0.7,fontSize:32,bold:true,color:'FFFFFF'});
T(s,'연령구조 · 공통 접촉행렬 SEIR로 본 2026-27절기 인플루엔자·코로나19 전망',{x:0.6,y:1.7,w:8.8,h:0.4,fontSize:15,color:ICE});
[['10월 43주','인플루엔자 정점 · ILI 85 (80% 61–117)'],['51%','인플루엔자·코로나19 입원 정점이 같은 달(10월)'],['−19%','접종 3주 앞당김의 입원 감소 효과']].forEach((d,i)=>{
  const x=0.6+i*3.0; s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y:2.75,w:2.75,h:1.55,fill:{color:'2B3A7A'},line:{color:'2B3A7A'},rectRadius:0.1});
  T(s,d[0],{x:x+0.2,y:2.9,w:2.4,h:0.7,fontSize:30,bold:true,color:CORAL}); T(s,d[1],{x:x+0.2,y:3.6,w:2.4,h:0.6,fontSize:11,color:'FFFFFF'}); });
T(s,'기점 2026-39주 · 전망 2026-40 ~ 2027-35',{x:0.6,y:4.75,w:8.8,h:0.3,fontSize:10,color:ICE});
s.addNotes('한 줄 결론: H1 여름 파동은 10월 중순 정점, 겨울 2차 파동은 H3·B 유입이 결정. 입원 부담은 10월에 두 병원체가 겹친다. 접종 시점이 범위만큼 중요.');

// 2 모형 구조
s=pres.addSlide(); s.background={color:'FFFFFF'}; title(s,'모형 구조: 접촉은 공유, 병원체 특성은 분리','β = 전파확률 × 계절성 × 공통 접촉행렬 C(t) · 접종 정책은 초기 감수성 인구 비율 S0로 반영');
s.addImage({path:F+'diagram.png',x:0.45,y:1.15,w:5.6,h:5.6/2.73});
s.addImage({path:F+'contact.png',x:0.45,y:3.35,w:5.6,h:5.6/5.0});
card(s,6.3,1.15,3.25,1.25,'공통 (공동 추정)','한국 연령별 접촉행렬 4층 (Prem 2017/2021)\n방학 중 학교 접촉 잔존율 0.60, 명절 0.35 (공동 추정)',CORAL);
card(s,6.3,2.5,3.25,1.25,'병원체별 (문헌값)','코로나 소아 감수성 0.40 (Davies 2020) → 같은 방학도 독감에 더 크게 작용',TEAL);
card(s,6.3,3.85,3.25,1.3,'아형 차이 = S0','세 아형은 같은 β, 초기 감수성 인구 비율 s와 연령 프로필이 다름.\n접종률×VE×일정이 S0를 줄임',NAVY);
foot(s,2); s.addNotes('기존 β 장부는 단일 집단이라 학교 방학 효과를 잔차 u가 흡수했다(계절 β R² 0.77). 연령 구조와 학사일정이 β에 직접 들어가면서 잔차 없이 R² 0.92.');

// 3 피팅
s=pres.addSlide(); title(s,'적합과 검증: 9개 절기 재현, 38주 기점 후향 검증','전역 모수 12개(κ는 문헌값 고정) + 절기·아형별 2개');
s.addImage({path:F+'flu_fit.png',x:0.45,y:1.15,w:5.9,h:5.9/1.5*0.98});
stat(s,6.65,1.15,2.9,'R² 0.91','인플루엔자 아형별 ILI+ 과거 8개 절기',CORAL);
stat(s,6.65,2.1,2.9,'WIS 4.92','후향 검증 3개 절기 · 기준모형 7.74',TEAL);
stat(s,6.65,3.05,2.9,'453만 건','모형 의료이용(2024-25) · 건강보험 청구 387만 건',NAVY);
T(s,'R0 1.82 (문헌 범위 내) · 코로나19 입원 log R² 0.88',{x:6.65,y:4.25,w:2.9,h:0.6,fontSize:10,color:GRAY});
foot(s,3); s.addNotes('오른쪽 아래: 공통 접촉 모수 프로파일 우도. 독감·코로나·합계 모두 같은 영역(0.6, 0.35)을 가리킨다.');

// 4 문제 1
s=pres.addSlide(); title(s,'문제 1 결과: 단기 예측 (기점 A–D, 34주, 39주)','팀 문제 1 결과 그림과 상대 WIS를 이 칸에 배치');
s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:0.45,y:1.2,w:5.8,h:3.9,fill:{color:LIGHT},line:{color:'C8D1E6',dash:'dash'},rectRadius:0.08});
T(s,'문제 1 결과 그림 자리\n(기점별 5주 분위수 vs 관측)',{x:0.45,y:2.6,w:5.8,h:0.9,fontSize:14,color:GRAY,align:'center'});
card(s,6.5,1.2,3.05,1.8,'연결 고리','1-나 → 1-다 변경 기록을 여기서 한 줄로.\n문제 2의 nowcast(26–39주 H1)가 같은 자료를 씀',TEAL);
card(s,6.5,3.15,3.05,1.95,'추가하면 좋은 것','상대 WIS 표 (A·B·C·D)\n추석 주(B, 39주) 보고 승수 1.32 반영 여부',CORAL);
foot(s,4); s.addNotes('이 슬라이드는 팀이 이미 제출한 문제 1 결과로 채운다. 문제지 7절 필수 장.');

// 5 대표 전망
s=pres.addSlide(); title(s,'문제 2 대표 전망: 10월 정점, 겨울은 아형이 결정','300개소 ILI · 코로나19 입원(ARI) · 50/80/95% 구간');
s.addImage({path:F+'brief.png',x:0.95,y:1.1,w:8.1,h:8.1/3.44});
const hd={bold:true,color:'FFFFFF',fill:{color:NAVY},fontFace:FONT,fontSize:9.5};
const c9={fontFace:FONT,fontSize:9.5,color:INK};
s.addTable([[{text:'시나리오',options:hd},{text:'정점 주',options:hd},{text:'정점 (80%)',options:hd},{text:'누적 (80%)',options:hd},{text:'가정',options:hd}],
 ['인플루엔자 REP','2026-43','85 (61–117)','1,101 (915–1,326)','A(H3N2)·B 유입 시점·규모를 과거 8개 절기에서 추출'],
 ['F1','2026-43','80 (55–112)','839 (741–936)','A(H3N2)·B 유입 없음: 10월 정점 후 겨울 유행 없음'],
 ['F2','2026-44','94 (71–131)','1,152 (1,038–1,271)','45–47주 A(H3N2) 유입: 10월 1차, 12–1월 2차 정점'],
 ['코로나19 REP','2026-43','521 (400–761)','5,159 (3,406–8,777)','변이 계통 교체 연 2.8회(포아송)'],
 ['C1 / C2','2026-42','465 / 518','3,687 / 6,408','C2: 50주 신규 변이 우세화 → 12–1월 2차 정점']].map((r,i)=>i?r.map(t=>({text:t,options:c9})):r),
 {x:0.45,y:3.55,w:9.1,colW:[1.2,1.2,1.35,1.75,3.6],rowH:0.22,border:{type:'solid',color:'DDE3F0',pt:0.75}});
foot(s,5); s.addNotes('대표 전망은 무조건 예측. 가중치 대신 H3·B 유입 여부·시점·감수성을 과거 적합값의 경험분포에서 뽑았다.');

// 6 정책 + Q-a
s=pres.addSlide(); title(s,'정책은 S0로: 접종 “시점”이 “범위”만큼 중요하다','같은 난수 짝비교 · 대표 전망 기준 독감 입원 누적');
s.addImage({path:F+'policy.png',x:0.45,y:1.15,w:9.1,h:9.1/3.5});
stat(s,0.45,3.95,2.1,'+24%','예년 일정(42주)일 때 입원',CORAL);
stat(s,2.65,3.95,2.1,'−10%','13–18세 국가접종 70%',TEAL);
stat(s,4.85,3.95,2.1,'51%','Q-a 두 입원 정점 같은 달(10월)',NAVY);
stat(s,7.05,3.95,2.5,'1,823명','Q-a 합계 정점 주 (80% 1,187–3,099)',NAVY);
foot(s,6); s.addNotes('정점(43주)이 접종 완료 전에 오기 때문에 시점 효과가 크다. 13-18세 접종은 학령기 감염 −29%로 고령층 입원까지 줄이는 간접효과. 절대 감염률은 식별 약함 → 상대효과로 해석.');

// 7 판별 + Q-c + 한계
s=pres.addSlide(); title(s,'판별 규칙 · 내년 여름 · 한계','2주 연속 80% 밖 = 경고 · 한 주라도 95% 밖 = 폐기');
const g={fill:{color:'E3F5E8'},fontFace:FONT,fontSize:10}, r={fill:{color:'FDE4E4'},fontFace:FONT,fontSize:10};
s.addTable([[{text:'ILI 주차',options:hd},{text:'중앙',options:hd},{text:'유지 (80%)',options:hd},{text:'버림 (95% 밖)',options:hd}],
 ...[['40','32.0','24.8–40.6','<21.7 / >44.7'],['41','48.9','35.7–68.1','<30.3 / >80.2'],['42','66.6','47.5–97.3','<38.6 / >117'],['43','74.9','51.3–109.4','<40.4 / >129']]
 .map(a=>[{text:a[0],options:c9},{text:a[1],options:c9},{text:a[2],options:g},{text:a[3],options:r}])],
 {x:0.45,y:1.2,w:4.6,colW:[0.9,0.8,1.4,1.5],rowH:0.3,border:{type:'solid',color:'DDE3F0',pt:0.75}});
T(s,[{text:'아래로 벗어나면 ',options:{bold:true}},{text:'H1 감수성 s↓ 먼저',options:{breakLine:true}},{text:'위로 벗어나면 ',options:{bold:true}},{text:'H1 전파력 승수 m↑ 먼저',options:{breakLine:true}},{text:'48주 전 H3+B ≥5% ',options:{bold:true}},{text:'→ 유입 시점 고정'}],{x:0.45,y:2.85,w:4.6,h:0.9,fontSize:10.5});
card(s,5.3,1.2,4.25,1.45,'Q-c 2027 여름 재유행 4.6%','기존 아형만으로는 0.6% · 여름 신규 계통 유입(과거 9개 여름 중 2회)을 확률 사건으로 포함',TEAL);
card(s,5.3,2.8,4.25,1.55,'한계','정점 규모는 의원 방문확률 가정에 민감(30%→58, 70%→145) · 접촉행렬 근사 · 13–18세 외래이용 미반영 · 검증 95% 포함률 0.78',GRAY);
s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:0.45,y:3.95,w:4.6,h:1.15,fill:{color:'FFF4E0'},line:{color:'F2C57C'},rectRadius:0.08});
T(s,'가장 불확실한 가정: 현재 A(H1N1)pdm09 초기 감수성 인구 비율 s≈0.90. s=0.60이면 정점 54, 12월 이후로 이동 → 40–41주가 판정',{x:0.6,y:4.03,w:4.3,h:1.0,fontSize:10.5,color:INK,valign:'middle'});
card(s,5.3,4.5,4.25,0.65,'다음 갱신: 41주 자료 직후','',NAVY);
foot(s,7);

// 8 문제 3 결과
s=pres.addSlide(); s.background={color:'FFFFFF'}; title(s,'문제 3: 같은 백신 물량의 최적 배분과 RSV 전망','차분진화 알고리즘 · 목적함수 = 외래+입원 진료비(연례보고서 건당 중앙값) · 총 접종 1,973만 회 고정');
s.addImage({path:F+'q3_opt.png',x:0.45,y:1.15,w:9.1,h:9.1/3.95});
s.addImage({path:F+'rsv_forecast.png',x:0.45,y:3.55,w:5.3,h:5.3/3.75});
card(s,5.95,3.5,3.6,1.65,'현행과의 차이','65세 이상 82% 유지 + 0–18세 약 90%, 시작 37주 → 입원 −23%(불확실성 반영, 현행보다 나을 확률 0.99). RSV: 정점 2026-53주 주 588건(395–784), 후향 검증 WIS 기준모형 대비 약 −50%',CORAL);
foot(s,8); s.addNotes('최적 B는 65세 이상 접종을 없애는 배분으로, 백신의 중증·사망 예방효과를 목적함수에 넣지 않았기 때문에 채택 불가. 최적 A가 현실적 대안. Medlock & Galvani 2009와 같은 방향(전파 중심 연령 집중).');
pres.writeFile({fileName:'/home/claude/ppt/T13_slides.pptx'}).then(()=>console.log('ok'));
