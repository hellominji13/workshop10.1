import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c
plt.rcParams['font.family']='Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus']=False
R=pickle.load(open('latent_demo.pkl','rb'))
NAVY='#1f3a5f'; COLS={'pc03':'#4292c6','pc05':'#1f3a5f','pc07':'#c0392b'}
LAB={'pc03':'가정 A','pc05':'가정 B','pc07':'가정 C'}
fig,ax=plt.subplots(1,3,figsize=(15.5,4.3),gridspec_kw=dict(width_ratios=[1.35,1,0.95]))
w=R['pc05']['w']; x=np.arange(len(w))
# (1) 관측: 세 가정 모두 거의 같은 곡선
ax[0].plot(x,R['pc05']['obs'],'o',color='k',ms=4,label='실제 관측 (ILI+)',zorder=5)
for t in ['pc03','pc05','pc07']:
    ax[0].plot(x,R[t]['model'],lw=2,color=COLS[t],alpha=.85,label=f"{LAB[t]} 모형")
tk=x[::8]; ax[0].set_xticks(tk); ax[0].set_xticklabels([f'{w[i]%100}주' for i in tk],fontsize=8.5)
ax[0].set_title('① 우리가 보는 것 — 세 가정 모두 관측을 똑같이 설명한다',fontsize=11,loc='left',color=NAVY)
ax[0].set_ylabel('ILI+ (외래 1,000명당)'); ax[0].legend(fontsize=9); ax[0].grid(alpha=.28)
ax[0].spines[['top','right']].set_visible(False)
# (2) 숨은 것: 감염 규모는 2배 차이
v=[R[t]['inf']/1e6 for t in ['pc03','pc05','pc07']]
b=ax[1].bar(range(3),v,color=[COLS[t] for t in ['pc03','pc05','pc07']],width=.58)
for i,val in enumerate(v): ax[1].text(i,val+0.8,f'{val:.0f}백만',ha='center',fontsize=11,fontweight='bold',color=NAVY)
ax[1].set_xticks(range(3)); ax[1].set_xticklabels([LAB[t] for t in ['pc03','pc05','pc07']],fontsize=10)
ax[1].set_ylim(0,max(v)*1.25); ax[1].set_ylabel('그 절기 실제 감염자 수 (추정)')
ax[1].set_title('② 숨어 있는 것 — 감염 규모는 2배 넘게 다르다',fontsize=11,loc='left',color=NAVY)
ax[1].spines[['top','right']].set_visible(False); ax[1].grid(alpha=.25,axis='y')
yb=max(v)*0.42
ax[1].annotate('',xy=(0,yb),xytext=(2,yb),arrowprops=dict(arrowstyle='<->',color='#c0392b',lw=1.8))
ax[1].text(1,yb,'2.1배',ha='center',fontsize=11,color='#c0392b',fontweight='bold',
           bbox=dict(boxstyle='round,pad=0.3',fc='white',ec='none'))
# (3) 해결책
ax[2].axis('off')
ax[2].text(0,0.97,'③ 그래서 무엇을 했나',fontsize=11,color=NAVY,fontweight='bold',va='top')
txt=[('외부 자료로 묶는다','건강보험 청구 의료이용 387만 건과\n모형 산출(453만)을 맞춰 확인'),
     ('문헌값으로 고정한다','관측 척도 κ = 발열 비율 × 방문 확률\n÷ 1인당 외래 횟수 = 0.58'),
     ('자유도를 줄인다','주별 전파력을 자유롭게 두지 않고\n접촉 × 계절 × 전파확률로 분해'),
     ('두 병원체를 함께 푼다','인플루엔자·코로나19가 같은 접촉\n구조를 공유 → 접촉 모수 공동 추정')]
yy=0.84
for h,d in txt:
    ax[2].text(0.02,yy,'●',fontsize=9,color='#c0392b',va='top')
    ax[2].text(0.09,yy,h,fontsize=10,fontweight='bold',color=NAVY,va='top')
    ax[2].text(0.09,yy-0.075,d,fontsize=8.8,color='#333',va='top'); yy-=0.235
fig.suptitle('같은 관측값을 만드는 숨은 상태는 하나가 아니다',fontsize=13.5,fontweight='bold',y=0.99)
fig.text(0.5,0.015,'※ 2024-2025절기. 세 가정은 "증상자가 의원을 찾을 확률"만 30% / 50% / 70%로 다르게 두고 전체를 각각 다시 적합한 결과이다.',
         ha='center',fontsize=8.6,color='#666')
fig.tight_layout(rect=[0,0.035,1,0.955]); fig.savefig('fig/latent.png',dpi=130)
print('ok')
