import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, rsv
plt.rcParams['font.family']='Noto Sans CJK JP'
f=pickle.load(open('rsv_fit.pkl','rb')); x=f['x']
h,st=rsv.sim(x,rsv.W,ret_state=True)
FW=c.week_range(202601,202717); rng=np.random.default_rng(0)
J=f['jac']; s2=(f['fun']**2).sum()/(len(f['fun'])-len(x)); cov=np.linalg.pinv(J.T@J)*s2*9
H=[]
for j in range(200):
    p=np.clip(rng.multivariate_normal(x,cov),rsv.LB,rsv.UB)
    hh,stj=rsv.sim(p,rsv.W,ret_state=True)
    f2=rsv.sim(p,FW,state=stj)*np.exp(rng.normal(0,0.15))
    H.append(f2*np.exp(rng.normal(0,0.1,len(FW))))
H=np.array(H); q=np.quantile(H,[.025,.1,.5,.9,.975],axis=0)
rep=c.week_range(202640,202717); ri=[FW.index(w) for w in rep]
pk=H[:,ri].max(1); pkw=np.array(rep)[H[:,ri].argmax(1)]
print('R2',1-((rsv.OBS-h)**2).sum()/((rsv.OBS-rsv.OBS.mean())**2).sum(),'peak',np.quantile(pk,[.1,.5,.9]).round(0),'peak week',np.percentile(pkw,[10,50,90]))
pickle.dump(dict(H=H,FW=FW,fit=h,q=q,pk=pk,pkw=pkw),open('rsv_fc.pkl','wb'))
fig,ax=plt.subplots(1,2,figsize=(15,4),gridspec_kw=dict(width_ratios=[1.6,1]))
xx=np.arange(len(rsv.W)); ax[0].plot(xx,rsv.OBS,'ko',ms=2,label='관측 (주간 RSV 검출)'); ax[0].plot(xx,h,color='#2a9d5c',lw=1.8,label='모형')
i0,i1=rsv.W.index(202010),rsv.W.index(202220); ax[0].axvspan(i0,i1,color='gray',alpha=.15); ax[0].text(i0+3,max(rsv.OBS)*0.85,'코로나19\n방역 기간',fontsize=9)
tk=[rsv.W.index(y*100+1) for y in range(2015,2026)]; ax[0].set_xticks(tk); ax[0].set_xticklabels(range(2015,2026)); ax[0].legend(fontsize=9); ax[0].set_title('RSV 적합 (2015–2025)')
xf=np.arange(len(FW)); ax[1].fill_between(xf,q[0],q[4],color='#2a9d5c',alpha=.15); ax[1].fill_between(xf,q[1],q[3],color='#2a9d5c',alpha=.3); ax[1].plot(xf,q[2],color='#2a9d5c',lw=2)
ax[1].axvspan(FW.index(202640),FW.index(202717),color='orange',alpha=.08); ax[1].text(FW.index(202640)+1,q[4].max()*0.95,'전망 구간 2026-40~2027-17',fontsize=9)
tk=[FW.index(w) for w in [202601,202614,202627,202640,202653,202710]]; ax[1].set_xticks(tk); ax[1].set_xticklabels(['26-01','26-14','26-27','26-40','26-53','27-10'])
ax[1].set_title('RSV 전망 (80·95% 구간)'); fig.tight_layout(); fig.savefig('fig/rsv_forecast.png',dpi=120)
