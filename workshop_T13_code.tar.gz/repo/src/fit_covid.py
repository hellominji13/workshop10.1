"""코로나19 적합: 연령 SEIRS + 변이 계통 점유율 증가분에 비례한 면역회피 + 계절성.
면역회피(주) = Σ_j e_j · max(Δ점유율_j,0)  (j: 계통군, 질병관리청 월별 점유율을 주 단위 선형보간)"""
import numpy as np, pandas as pd, pickle, sys, common as c, covid as cv
from scipy.optimize import least_squares, differential_evolution
D=c.load_covid(); W=c.week_range(202401,202639); OBS=D.loc[W,'ARI'].values.astype(float)
FAM={'KP':['KP.2','KP.3'],'XEC':['XEC','XEL'],'LP.8.1':['LP.8.1'],'NB':['NB.1.8.1','PQ.2'],'BA.3.2':['BA.3.2'],'PQ.16.1.1':['PQ.16.1.1']}
def variant_weekly():
    x=pd.read_excel(c.D+'variant.xlsx',header=None)
    yrs=x.iloc[0,1:].ffill(); mon=x.iloc[1,1:]
    v=x.iloc[2:,1:].astype(float).fillna(0); v.index=x.iloc[2:,0]
    mids=[pd.Timestamp(int(str(y)[:4]),int(str(m).replace('월','')),15) for y,m in zip(yrs,mon)]
    out={}
    for f,ls in FAM.items():
        s=v.loc[ls].sum(0).values/100
        out[f]=s
    wk=np.array([pd.Timestamp(c.week_start(w)).value for w in c.week_range(202001,202735)],float)
    mv=np.array([m.value for m in mids],float)
    allw=c.week_range(202001,202735)
    return {f:dict(zip(allw,np.interp(wk,mv,s))) for f,s in out.items()}
VW=variant_weekly()
SEAS=sys.argv[1] if len(sys.argv)>1 and sys.argv[1] in ('AH','HARM') else 'HARM'
P=['R0','s1','s2','logS0','logI0','logeta','hrep','wane','lrep2']+['e_'+k for k in FAM]
_ALL=c.week_range(202001,202735)
DV={f:{yw:max(VW[f][yw]-VW[f][p],0) for p,yw in zip(_ALL[:-1],_ALL[1:])} for f in FAM}   # 주별 점유율 증가분
for f in FAM:
    for yw in _ALL:
        if yw>=202634: DV[f][yw]=0.0        # 2026-08월 이후 점유율 미관측 → 증가분 0 (시나리오에서 별도 부여)
def escapes(d,weeks):
    return {yw:min(sum(d['e_'+f]*DV[f].get(yw,0) for f in FAM),0.95) for yw in weeks}
def run(x,vs,hr,weeks=W,qmult=None,state=None,vac=None,extra=None,seas=None):
    seas=seas or SEAS
    d=dict(zip(P,x))
    p=dict(R0=d['R0'],theta=(d['s1'] if seas=='AH' else 0.0),wane_days=d['wane'],S0=np.exp(d['logS0']),I0=np.exp(d['logI0']))
    if seas=='HARM':
        t=np.array([(c.week_start(w)-c.week_start(202401)).days/365.25 for w in weeks])
        hm=np.exp(d['s1']*np.cos(2*np.pi*t)+d['s2']*np.sin(2*np.pi*t))
        qmult=hm if qmult is None else qmult*hm
    esc=escapes(d,weeks)
    if extra:
        for k,v in extra.items(): esc[k]=1-(1-esc.get(k,0))*(1-v)
    inc,st=cv.simulate(weeks,p,vs,hr,escapes=esc,qmult=qmult,state=state,vac=vac)
    h=cv.hosp(inc,np.exp(d['logeta']))
    hol=np.array([d['hrep'] if yw in c.HOLIDAY else 1 for yw in weeks])
    # 2024-08-31 코로나19 4급 전환 이후 검사·신고 감소 → 입원 확인률 단계 변화
    # 2024-08-31 코로나19 4급 전환 이후 검사·신고 감소 → 입원 확인률 단계 변화
    rep=np.array([np.exp(d['lrep2']) if yw>=202436 else 1 for yw in weeks])
    return h*hol*rep,inc,st
def resid(x,vs,hr):
    h,_,_=run(x,vs,hr); r=np.log(h+10)-np.log(OBS+10)
    d=dict(zip(P,x)); pri=[(d['hrep']-0.8)/0.2,(d['wane']-240)/90]
    return np.r_[r,pri]
LB=np.r_[[1.2,-0.6,-0.6,np.log(0.02),np.log(1e-6),-14,0.4,90,-2.5],[0]*len(FAM)]
UB=np.r_[[8,0.6,0.6,np.log(0.9),np.log(3e-2),-2,1.5,500,0.5],[1.0]*len(FAM)]
if SEAS=='AH': LB[1],UB[1],LB[2],UB[2]=-0.15,0.15,-1e-9,1e-9
def fit_de(vs,hr,seed=1,maxiter=150):
    obj=lambda x: float(np.sum(resid(x,vs,hr)**2))
    r=differential_evolution(obj,list(zip(LB,UB)),seed=seed,maxiter=maxiter,popsize=12,tol=1e-8,polish=False)
    return least_squares(resid,r.x,bounds=(LB,UB),args=(vs,hr),x_scale='jac',max_nfev=300)
if __name__=='__main__':
    vs,hr=float(sys.argv[2]),float(sys.argv[3])
    b=fit_de(vs,hr); d=dict(zip(P,b.x)); print(SEAS,{k:round(v,4) for k,v in d.items()},'cost',b.cost)
    h,_,_=run(b.x,vs,hr); R2=1-((OBS-h)**2).sum()/((OBS-OBS.mean())**2).sum(); print('R2',R2)
    pickle.dump(dict(x=b.x,jac=b.jac,fun=b.fun,vs=vs,hr=hr,seas=SEAS,cost=b.cost),open(f'covid_fit_{SEAS}.pkl','wb'))
