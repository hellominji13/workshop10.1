import numpy as np, pickle, forecast_flu as f
fi=[f.ALLW.index(w) for w in f.REPORT]; out={}
for s in [0.6,0.75,0.89]:
    o=f.run('REP',seed=5,s_fix=s); x=o['ili'][:,fi]; h=o['hosp'][:,fi]
    out[s]=dict(q=np.quantile(x,[.1,.5,.9],axis=0),pk=np.quantile(x.max(1),[.1,.5,.9]),pkw=np.median(x.argmax(1)+1),cum=np.median(x.sum(1)),hcum=np.median(h.sum(1)))
    print(s,out[s]['pk'].round(1),out[s]['pkw'],round(out[s]['cum']),round(out[s]['hcum']))
pickle.dump(out,open('sens_s.pkl','wb'))
