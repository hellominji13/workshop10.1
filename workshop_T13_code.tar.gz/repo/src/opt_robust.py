"""최적 배분 A의 강건성: 사후표본·시나리오별로 현행 대비 입원 감소를 짝지은 비교. 배분 효과와 시기 효과 분리."""
import numpy as np, pickle, flu, forecast_flu as f
K=pickle.load(open('opt_keep65.pkl','rb')); A=K['x'][:6]; tA=int(round(K['x'][6]))
fi=[f.ALLW.index(w) for w in f.REPORT]; out={}
for scn in ['REP','F1','F2']:
    res={}
    for nm,cov,st in [('현행 39주',flu.COV,39),('현행 37주',flu.COV,tA),('최적A 39주',A,39),('최적A 37주',A,tA)]:
        o=f.run(scn,seed=77,cov=cov,vstart=st,N=600); res[nm]=o['hosp'][:,fi].sum(1)
    base=res['현행 39주']; out[scn]={k:dict(med=np.median(v),d=np.median(v/base-1)*100,lo=np.quantile(v/base-1,.1)*100,hi=np.quantile(v/base-1,.9)*100,pbetter=np.mean(v<base)) for k,v in res.items()}
    for k,v in out[scn].items(): print(scn,k,round(v['med']),f"{v['d']:+.1f}% ({v['lo']:+.1f}~{v['hi']:+.1f}) P(개선)={v['pbetter']:.2f}")
# s 민감도
for s in [0.6,0.75]:
    r1=f.run('REP',seed=78,N=600,s_fix=s)['hosp'][:,fi].sum(1); r2=f.run('REP',seed=78,N=600,s_fix=s,cov=A,vstart=tA)['hosp'][:,fi].sum(1)
    out[f's{s}']=dict(d=np.median(r2/r1-1)*100,p=np.mean(r2<r1)); print('s',s,out[f's{s}'])
pickle.dump(out,open('opt_robust.pkl','wb'))
