"""제출용 장형 csv(부록 A) + 정책 질문(Q-a, Q-b, Q-c) 계산."""
import numpy as np, pandas as pd, pickle, common as c
import forecast_flu as ffc
TEAM='T13'; MODEL='ageSEIR_sharedContact'
QL=[0.025,0.10,0.25,0.50,0.75,0.90,0.975]
FL=pickle.load(open('flu_scen.pkl','rb')); CV=pickle.load(open('covid_scen.pkl','rb'))
REPORT=c.week_range(202640,202735)
def ix(allw): return [allw.index(w) for w in REPORT]
rows=[]
def add(target,scn,X):
    q=np.quantile(X,QL,axis=0)
    for t,w in enumerate(REPORT):
        for k,qq in enumerate(QL): rows.append([TEAM,MODEL,'2','2026-39',scn,target,f'{w//100}-{w%100:02d}',t+1,qq,max(q[k,t],0)])
    for nm,v in [('peak_week',X.argmax(1)+1),('peak_value',X.max(1)),('cum_total',X.sum(1))]:
        for k,qq in enumerate(QL): rows.append([TEAM,MODEL,'2','2026-39',scn,f'{target}_{nm}','NA','NA',qq,float(np.quantile(v,qq))])
fi=ix(ffc.ALLW); ci=ix(CV['ALLW'])
for s in ['REP','F1','F2']:
    add('ili',s,FL[s]['ili'][:,fi]); add('flu_hosp',s,FL[s]['hosp'][:,fi])
for s in ['REP','C1','C2']:
    add('covid_ari',s,CV['out'][s][:,ci])
df=pd.DataFrame(rows,columns=['team_id','model_id','task','origin','scenario_id','target','target_week','horizon','quantile','value'])
df.to_csv('submission_task2_long.csv',index=False)
# ---- Q-a: 동시 정점 (대표 전망, 독립 짝짓기) ----
rng=np.random.default_rng(0)
fh=FL['REP']['hosp'][:,fi]; ch=CV['out']['REP'][:,ci]; n=min(len(fh),len(ch))
fh=fh[rng.permutation(len(fh))[:n]]; ch=ch[rng.permutation(len(ch))[:n]]
month=np.array([c.week_start(w).month+ (100*c.week_start(w).year) for w in REPORT])
mf=month[fh.argmax(1)]; mc=month[ch.argmax(1)]; same=(mf==mc)
tot=fh+ch
qa=dict(p_same=same.mean(), same_month_dist=pd.Series(mf[same]).value_counts(normalize=True).to_dict(),
        tot_peak=np.quantile(tot.max(1),QL), tot_peak_week=pd.Series([REPORT[i] for i in tot.argmax(1)]).value_counts(normalize=True).head(5).to_dict(),
        flu_pk_month=pd.Series(mf).value_counts(normalize=True).to_dict(), cov_pk_month=pd.Series(mc).value_counts(normalize=True).to_dict())
# ---- Q-b: 판별 규칙 (40~43주 ILI) ----
X=FL['REP']['ili'][:,fi]
qb={REPORT[t]:np.quantile(X[:,t],[0.025,0.1,0.5,0.9,0.975]) for t in range(4)}
# ---- Q-c: 2027-27~35 ILI > 12.9 ----
sm=[REPORT.index(w) for w in REPORT if 202727<=w<=202735]
qc={s:float((FL[s]['ili'][:,fi][:,sm]>12.9).any(1).mean()) for s in ['REP','F1','F2']}
pickle.dump(dict(qa=qa,qb=qb,qc=qc),open('policy.pkl','wb'))
print('Q-a',qa); print('Q-b',{k:v.round(1) for k,v in qb.items()}); print('Q-c',qc)
