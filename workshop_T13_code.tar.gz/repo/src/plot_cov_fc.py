import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c
plt.rcParams['font.family']='Noto Sans CJK JP'
d=pickle.load(open('covid_scen.pkl','rb')); A=d['ALLW']; O=c.load_covid()
fig,ax=plt.subplots(1,3,figsize=(18,4.8),sharey=True); col={'REP':'#444','C1':'#7b3fbf','C2':'#d1495b'}
s0=A.index(202601); i39=A.index(202639)
for k,s in enumerate(['REP','C1','C2']):
    H=d['out'][s]; q=np.quantile(H,[.025,.1,.25,.5,.75,.9,.975],axis=0); x=np.arange(len(A))
    m=x>=i39
    ax[k].fill_between(x[m],q[0][m],q[6][m],color=col[s],alpha=.12); ax[k].fill_between(x[m],q[1][m],q[5][m],color=col[s],alpha=.2); ax[k].fill_between(x[m],q[2][m],q[4][m],color=col[s],alpha=.3)
    ax[k].plot(x[m],q[3][m],color=col[s],lw=2)
    hw=[w for w in A if w<=202639 and w>=202601]; ax[k].plot([A.index(w) for w in hw],O.loc[hw,'ARI'],'ko',ms=3)
    ax[k].set_xlim(s0,len(A)); tk=[A.index(w) for w in [202601,202614,202627,202640,202653,202713,202726]]
    ax[k].set_xticks(tk); ax[k].set_xticklabels(['26-01','26-14','26-27','26-40','26-53','27-13','27-26'],fontsize=8)
    ax[k].set_title({'REP':'ARI — 대표 전망 (REP)','C1':'ARI — C1: 신규 변이 우세화 없음','C2':'ARI — C2: 2026-50 신규 변이 우세화'}[s])
ax[0].set_ylabel('코로나19 입원 (ARI, 주)'); fig.tight_layout(); fig.savefig('fig/covid_forecast.png',dpi=110)
