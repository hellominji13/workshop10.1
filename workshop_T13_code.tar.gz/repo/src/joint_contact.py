"""공통 접촉 모수(방학 중 학교접촉 잔존율 v, 명절 접촉 잔존율 h)의 결합 프로파일 우도.
각 격자점에서 독감 전역모수(절기별 모수 고정)와 코로나 모수를 재적합 → 프로파일 로그우도 합이 최대인 점."""
import numpy as np, pickle, sys, common as c, fit_flu as ff, fit_covid as fc
from scipy.optimize import least_squares
FF=pickle.load(open('flu_fit.pkl','rb')); CF=pickle.load(open(sys.argv[1],'rb')); fc.SEAS=CF['seas']
iv,ih=ff.G.index('vac_school'),ff.G.index('hol_red')
free=[i for i in range(ff.NG) if i not in (iv,ih)]
def flu_prof(v,h):
    x=FF['x'].copy(); x[iv]=v; x[ih]=h
    def r(z):
        y=x.copy(); y[free]=z; rr=ff.resid(y); return rr[:-4]   # 사전항 제외(접촉 사전 제거)
    s=least_squares(r,x[free],bounds=(ff.LB[free],ff.UB[free]),max_nfev=15,x_scale='jac')
    return (s.fun**2).sum(),len(s.fun)
def cov_prof(v,h):
    s=least_squares(fc.resid,CF['x'],bounds=(fc.LB,fc.UB),args=(v,h),max_nfev=60,x_scale='jac')
    return (s.fun[:-2]**2).sum(),len(s.fun)-2
if __name__=='__main__':
    V=[0.3,0.45,0.6,0.75,0.9]; Hh=[0.2,0.35,0.5,0.7,0.9]; res=[]
    for v in V:
        for h in Hh:
            a,na=flu_prof(v,h); b,nb=cov_prof(v,h)
            res.append((v,h,-na/2*np.log(a/na),-nb/2*np.log(b/nb))); print(res[-1],flush=True)
    pickle.dump(res,open('joint.pkl','wb'))
