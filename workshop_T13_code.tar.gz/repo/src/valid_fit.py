"""후향 검증 1단계: 기점(대상 절기 38주) 이전에 끝난 절기만으로 전역 모수 재적합 (정보 차단)."""
import numpy as np, pandas as pd, pickle, sys, common as c, flu
from scipy.optimize import least_squares, minimize
import fit_flu as ff
TARGET=int(sys.argv[1])            # 대상 절기 시작 연도 (2023, 2024, 2025)
ORIGIN=TARGET*100+38
TRAIN=[(a,b) for (a,b) in ff.SEASONS[:8] if b<ORIGIN]
F=ff.F[ff.F.index<=ORIGIN]
# 외래 연령 비중 π: 기점 이전 연령 자료만으로 재추정
A=ff.AGE[(ff.AGE.yw<=ORIGIN)&(ff.AGE[c.AGES].min(axis=1)>0)&(ff.AGE.ILI>0)]
X=A[c.AGES].values; y=A.ILI.values; p0=c.N/c.N.sum()
def fobj(z): p=np.exp(z)/np.exp(z).sum(); return ((np.log(X@p)-np.log(y))**2).sum()+0.5*((np.log(p)-np.log(p0))**2).sum()
z=minimize(fobj,np.log(p0),method='Nelder-Mead',options=dict(maxiter=20000,xatol=1e-6,fatol=1e-9)).x
flu.PI=np.exp(z)/np.exp(z).sum()
AGE=A
NS=len(TRAIN); NG=ff.NG
def unpack(x): return dict(zip(ff.G,x[:NG])), x[NG:].reshape(NS,3,2)
def resid(x):
    g,loc=unpack(x); out=[]; kap=np.exp(g['logkappa'])
    for i,(a,b) in enumerate(TRAIN):
        w=c.week_range(a,b); sig=ff.sigma(g); s=1/(1+np.exp(-loc[i,:,0]))
        S0=np.minimum(s[:,None]*sig,0.995); I0=np.exp(loc[i,:,1])[:,None]*np.ones(6)
        inc,_=flu.simulate(w,S0,I0,g['theta'],g['vac_school'],g['hol_red'],qmult=np.full(len(w),g['R0']/flu.R0))
        tot,age=flu.obs_ili(inc,kap); hol=np.array([g['hrep'] if yw in c.HOLIDAY else 1 for yw in w])
        r=np.sqrt(tot*hol[:,None])-np.sqrt(F.loc[w,['H1p','H3p','Bp']].values); r[np.isnan(r)]=0; out.append(r.ravel())
        Aa=AGE[AGE.yw.isin(w)]
        if len(Aa):
            idx=[w.index(v) for v in Aa.yw]; m=age[idx]*np.exp(g['logkA'])*hol[idx][:,None]
            o=Aa[c.AGES].values*F.loc[Aa.yw,'pos'].values[:,None]/100; out.append(0.5*(np.sqrt(m)-np.sqrt(o)).ravel())
    out.append(np.array([(g['theta']-0.05)/0.05,(g['vac_school']-0.3)/0.3,(g['hol_red']-0.5)/0.3,(g['hrep']-1.3)/0.3]))
    return np.concatenate(out)
if __name__=='__main__':
    full=pickle.load(open('flu_fit.pkl','rb'))['x']
    g0=full[:NG]; loc0=np.zeros((NS,3,2)); loc0[:,:,0]=0.5; loc0[:,:,1]=-12
    x0=np.r_[g0,loc0.ravel()]          # 시작값만 빌림(최적화가 다시 수렴), 대상 절기 모수는 포함 안 됨
    # 시작값 영향 배제: 전역모수를 기본값으로 시작
    x0[:NG]=[1.6,0.05,0.3,0.5,np.log(flu.KAPPA),1.3,0.0,0.3,-0.3,0.3,-0.3,0.3,-0.3]
    LB=np.r_[ff.LB[:NG],np.tile([-4,-30],NS*3)]; UB=np.r_[ff.UB[:NG],np.tile([4,-4],NS*3)]
    r0=resid(x0); sp=np.zeros((len(r0),len(x0)),int); sp[:,:NG]=1; st=0
    for i,(a,b) in enumerate(TRAIN):
        w=c.week_range(a,b); n=len(w)*3+len(AGE[AGE.yw.isin(w)])*6; sp[st:st+n,NG+i*6:NG+(i+1)*6]=1; st+=n
    sol=least_squares(resid,x0,bounds=(LB,UB),jac_sparsity=sp,x_scale='jac',max_nfev=300)
    g,loc=unpack(sol.x)
    J=sol.jac.toarray(); s2=(sol.fun**2).sum()/(len(sol.fun)-len(sol.x))
    covg=np.linalg.pinv(J[:,:NG].T@J[:,:NG])*s2*9
    pickle.dump(dict(x=sol.x,covg=covg,train=TRAIN,PI=flu.PI,origin=ORIGIN),open(f'valid_{TARGET}.pkl','wb'))
    print(TARGET,'train',[a//100 for a,b in TRAIN],{k:round(v,3) for k,v in g.items()},'cost',sol.cost)
