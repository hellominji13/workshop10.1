import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, flu, fit_flu as ff
plt.rcParams['font.family']='Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus']=False
fit=pickle.load(open('flu_fit.pkl','rb')); r,keep=ff.resid(fit['x'],True)
col={'H1':'#2a6fdb','H3':'#e0542e','B':'#2a9d5c'}
fig,ax=plt.subplots(3,3,figsize=(15,10)); ax=ax.ravel(); stats=[]
for i in range(ff.NS):
    w,inc,tot,age=keep[i]; x=np.arange(len(w))
    obs=ff.F.loc[w,['H1p','H3p','Bp']].values
    for k,s in enumerate(flu.SUB):
        if i==ff.NS-1 and k>0: continue
        ax[i].plot(x,obs[:,k],'o',ms=3,color=col[s],alpha=.6); ax[i].plot(x,tot[:,k],'-',color=col[s],lw=2,label=s)
    o=np.nansum(obs,1); m=tot.sum(1) if i<ff.NS-1 else tot[:,0]
    if i==ff.NS-1: o=obs[:,0]
    R2=1-np.nansum((o-m)**2)/np.nansum((o-np.nanmean(o))**2); stats.append((ff.SNAME[i],R2))
    ax[i].set_title(f'{ff.SNAME[i]}  R²={R2:.2f}'); tk=x[::8]; ax[i].set_xticks(tk); ax[i].set_xticklabels([f'{w[j]%100}주' for j in tk],fontsize=8)
ax[0].legend(); fig.suptitle('인플루엔자 아형별 ILI+ (점=관측, 선=모형) — 연령구조 SEIR, 공통 접촉행렬',fontsize=14)
fig.tight_layout(); fig.savefig('fig/flu_fit.png',dpi=110); print(stats)
