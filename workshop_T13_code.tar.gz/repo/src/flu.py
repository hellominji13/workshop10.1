"""인플루엔자: 연령(6) × 아형(H1,H3,B) SEIR + 접종(S→V), 공통 접촉행렬 사용.
β_k,ab(t) = q_flu · exp(-θ_AH·(AH_t-AH̄)) · C_ab(t)      (아형 간 전파력 동일)
아형 차이 = 연령별 감수성 프로필 σ_k,a × 절기별 감수성 수준 s_k,season  (→ S0)
관측: 연령별 ILI+_a = κ·(주간 감염/인구)·1000, 전체 ILI+ = Σ π_a ILI+_a (π: 연령별 외래 비중, 연령 ILI 자료로 추정)"""
import numpy as np, common as c
SUB=['H1','H3','B']
PI=np.array([0.218,0.073,0.056,0.32,0.2,0.132])        # 외래 연령 비중 (연령별 ILI → 전체 ILI 회귀, R²(log)=0.98)
LAT=2.0; INF=3.0          # 잠복기 2일(Lessler 2009 중앙 1.4~1.9일), 감염기간 3일(Carrat 2008 바이러스 배출) → 세대기간 ~3.6일 (Cowling 2009)
R0=1.6                    # 완전 감수성 집단에서의 R0 (Biggerstaff 2014 체계적 고찰: 2009 대유행 중앙값 1.46, 계절 1.28 → 감수성 s로 흡수)
AHBAR=c.AH.mean()
# 접종: 연령별 접종률 (질병관리청 국가 인플루엔자 연례보고서 2026: 6개월~13세 70.0%, 65세 이상 81.6%;
#      13~18세는 13세만 국가접종 → 0.2, 19~49 0.15, 50~64 0.35: 국민건강영양조사 성인 접종률 범위)
COV=np.array([0.70,0.70,0.20,0.15,0.35,0.816])
VE=np.array([0.61,0.33,0.54])   # 아형별 감염예방 효과 (Belongia 2016 Lancet ID 메타분석: H1pdm 61%, H3 33%, B 54%)

# 관측 척도 κ: 문헌값으로 고정 (식별성 확보)
#   ILI+(외래 1,000명당) = 1000 × 주간 감염률 × P(ILI 정의 증상) × P(의원 방문 | 증상) ÷ 1인당 주간 외래 방문 수
P_SYM=0.35      # 감염 중 발열 동반 비율 37% (Carrat 2008 인체 감염 실험 종합)
import os
P_CONS=float(os.environ.get('P_CONS','0.50'))     # 증상자 의원 방문 확률 (가정, 민감도 0.3~0.7)
VISITS=15.7/52  # 한국 1인당 연간 외래 진료 15.7회 (OECD Health Statistics 2023)
KAPPA=P_SYM*P_CONS/VISITS
def q_from_R0(R0, vac_school=1.0):
    C=c.contact(202645,1,1)
    ev=np.max(np.abs(np.linalg.eigvals(C*INF)))   # NGM = q·C·D (감수성 1)
    return R0/ev
Q=q_from_R0(R0)

def vac_schedule(yw, start=None):
    """주당 접종 비율(연령별). 어린이 접종 시작주부터 6주, 65세 이상은 2주 뒤 시작 5주, 성인 8주에 걸쳐."""
    w=yw%100; y=yw//100
    st=start if start is not None else 40
    k=(w-st) if w>=36 else (w+52-st)
    r=np.zeros(c.NA)
    if 0<=k<6: r[[0,1,2]]=1/6
    if 2<=k<7: r[5]=1/5
    if 0<=k<8: r[[3,4]]=1/8
    return r

def simulate(weeks, S0, I0, theta, vac_school, hol_red, cov=COV, ve=VE, vstart=40, qmult=None, seed_add=None, state=None, reset=None):
    """weeks: 주차 목록. S0: (3,6) 감수성 비율, I0: (3,6) 초기 감염 비율.
    반환: inc (주,3,6) 주간 신규감염 비율, state"""
    nW=len(weeks)
    if state is None:
        S=S0.copy(); E=I0*LAT/INF; I=I0.copy(); V=np.zeros_like(S)
    else: S,E,I,V=[x.copy() for x in state]
    inc=np.zeros((nW,3,c.NA)); dt=1.0
    for t,yw in enumerate(weeks):
        C=c.contact(yw,vac_school,hol_red)
        f=np.exp(-theta*(c.ah_at(yw)-AHBAR))
        qm=1.0 if qmult is None else qmult[t]      # 스칼라 또는 아형별 길이 3 벡터
        qv=np.atleast_1d(qm); beta=Q*f*C            # (6,6)
        vr=vac_schedule(yw,vstart)*cov             # 주당 접종 비율
        if seed_add is not None and seed_add[t] is not None:
            I=I+seed_add[t]
        if reset is not None and t in reset:      # 신규 계통 유입: 해당 아형의 감수성 인구를 새 수준으로(기존 면역이 새 계통을 막지 못함)
            k,newS=reset[t]; S[k]=np.maximum(S[k],newS); I[k]=I[k]+1e-5
        for d in range(7):
            lam=(beta@(I.T)).T*(qv[:,None] if qv.size==3 else qv[0])   # (3,6)  I는 이미 비율
            nE=lam*S*dt
            S=S-nE; E=E+nE-E/LAT; I=I+E/LAT-I/INF
            inc[t]+=E/LAT
            # 접종: 감수성자 중 접종자 × VE 만큼 면역(전부-아니면-전무형, 2주 지연은 주간 해상도에서 생략)
            dv=(vr/7)[None,:]*S*ve[:,None]
            S=S-dv; V=V+dv
    return inc,(S,E,I,V)

def obs_ili(inc, kappa):
    """inc (W,3,6) → 아형별 전체 ILI+ (W,3), 연령별 ILI+ (W,6)"""
    age=kappa*1000*inc                     # 연령별 ILI+ (아형별)
    tot=(age*PI[None,None,:]).sum(2)
    return tot, age.sum(1)
