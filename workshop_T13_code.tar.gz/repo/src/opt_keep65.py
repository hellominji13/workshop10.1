import numpy as np, pickle, opt_flu as o, flu, common as c
from scipy.optimize import differential_evolution
D65=0.816*c.N[5]; REST=o.DOSES0-D65
def obj(z):
    cov=np.r_[np.clip(z[:5],0,0.9),0.816]; d=(cov[:5]*c.N[:5]).sum(); cov[:5]=np.clip(cov[:5]*REST/max(d,1),0,0.9)
    r=o.evaluate(cov,z[5]); pen=abs((cov*c.N).sum()-o.DOSES0)/o.DOSES0*1e4
    return (r['out']+r['hosp_cost'])/1e8+pen
hist=[]
r=differential_evolution(obj,[(0,0.9)]*5+[(36,46)],seed=4,maxiter=80,popsize=12,tol=1e-9,polish=False,callback=lambda xk,convergence=None: hist.append(obj(xk)))
cov=np.r_[np.clip(r.x[:5],0,0.9),0.816]; d=(cov[:5]*c.N[:5]).sum(); cov[:5]=np.clip(cov[:5]*REST/d,0,0.9)
res=o.evaluate(cov,r.x[5]); res['x']=np.r_[cov,r.x[5]]; res['hist']=hist
pickle.dump(res,open('opt_keep65.pkl','wb'))
print('keep65',np.round(res['x'],2),'cost',round(res['cost']/1e8),'out',round(res['out']/1e8),'hosp',round(res['hosp']),'hospcost',round(res['hosp_cost']/1e8),'doses',round(res['doses']/1e4))
