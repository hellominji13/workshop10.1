import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import common as c
plt.rcParams['font.family']='Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus']=False
A=pickle.load(open('evo_grid_A.pkl','rb')); B=pickle.load(open('evo_grid_B.pkl','rb'))
T=pickle.load(open('evo_timing.pkl','rb')); O=pickle.load(open('evo_opt2.pkl','rb'))
NAVY='#1f3a5f'
fig=plt.figure(figsize=(16.5,9.8))
fig.text(0.5,0.975,'새로 등장한 바이러스가 유행을 일으키려면 어떤 조건이 필요한가',ha='center',fontsize=15,fontweight='bold')
# 설명 머리글
fig.text(0.5,0.945,'새 바이러스를 두 가지 성질로만 나타낸다.   ① 얼마나 빨리 퍼지는가   ② 사람들이 이미 가진 면역을 얼마나 비껴가는가',
         ha='center',fontsize=10.5,color='#333')
ax=[fig.add_axes([0.07,0.555,0.245,0.325]),fig.add_axes([0.375,0.555,0.255,0.325]),
    fig.add_axes([0.055,0.115,0.40,0.315]),fig.add_axes([0.555,0.115,0.40,0.315])]
cb=fig.add_axes([0.655,0.555,0.013,0.325])
XL='잘 퍼지는 정도  (지금 유행 중인 바이러스 = 1.0)'
YL='기존 면역을 비껴가는 정도\n(0 = 기존 면역이 그대로 막아줌,  1 = 전혀 막지 못함)'
vmax=max(A['Z'].max(),B['Z'].max())/1e6
TT=[('(가) 지금 (2026년 10~11월)  — 아직 면역을 가진 사람이 적은 상태',
     '지금은 걸릴 수 있는 사람이 많이 남아 있다.\n→ 빠르게 퍼지기만 하면 유행이 가능하고,\n   면역을 비껴가는 능력은 거의 필요 없다.'),
    ('(나) 이번 겨울이 지난 뒤 (2027년 가을)  — 많은 사람이 면역을 가진 상태',
     '큰 유행을 겪고 나면 걸릴 사람이 줄어든다.\n→ 아무리 빨라도 기존 면역을 비껴가지 못하면\n   유행을 만들지 못한다 (아래쪽이 전부 흰색).')]
for k,(D,(tt,note)) in enumerate(zip([A,B],TT)):
    im=ax[k].imshow(D['Z']/1e6,origin='lower',aspect='auto',cmap='YlOrRd',vmin=0,vmax=vmax,
                    extent=[D['TAU'][0],D['TAU'][-1],D['EPS'][0],D['EPS'][-1]])
    cs=ax[k].contour(D['TAU'],D['EPS'],D['Z']/1e6,levels=[1,5,10,20,30],colors='k',linewidths=.55)
    ax[k].clabel(cs,inline=True,fontsize=7,fmt='%g')
    ax[k].set_xlabel(XL,fontsize=9); ax[k].set_title(tt,fontsize=10,loc='left',color=NAVY)
    ax[k].set_xlim(D['TAU'][0],D['TAU'][-1]); ax[k].set_ylim(0,0.9)
    ax[k].text(0.615,0.87,note,fontsize=8.4,va='top',color='#111',
               bbox=dict(boxstyle='round,pad=0.42',fc='white',ec='#bbb',alpha=.93))
ax[0].set_ylabel(YL,fontsize=8.8,labelpad=6)
fig.colorbar(im,cax=cb); cb.set_ylabel('그 바이러스가 한 절기 동안\n감염시키는 사람 수 (백만 명)',fontsize=8.5,labelpad=8)
# (다) 유입 시점
x=np.arange(len(T['WKS'])); lab=[f"{w//100%100}년 {w%100}주" for w in T['WKS']]
ax[2].plot(x,np.array(T['no_escape'])/1e6,color='#c0392b',lw=2.3,label='면역을 못 비껴가는 바이러스')
ax[2].plot(x,np.array(T['escape'])/1e6,color=NAVY,lw=2.3,label='면역을 절반쯤 비껴가는 바이러스')
iw=T['WKS'].index(202736) if 202736 in T['WKS'] else len(x)//2
ax[2].axvline(iw,ls='--',color='gray',lw=1)
ax[2].annotate('다음 절기 시작',xy=(iw,ax[2].get_ylim()[1]*0.55),xytext=(iw-9,ax[2].get_ylim()[1]*0.72),
               fontsize=8.5,color='#555',arrowprops=dict(arrowstyle='->',color='#888',lw=.9))
ax[2].annotate('10월 초를 놓치면\n이번 절기에는 기회가 없다',xy=(5,2),xytext=(9,13),fontsize=9,
               arrowprops=dict(arrowstyle='->',color='#555',lw=1))
ax[2].annotate('면역을 비껴가는 바이러스만\n1년 뒤 두 번째 기회를 얻는다',xy=(36,3.2),xytext=(24,9),fontsize=9,color=NAVY,
               arrowprops=dict(arrowstyle='->',color=NAVY,lw=1))
tk=x[::6]; ax[2].set_xticks(tk); ax[2].set_xticklabels([lab[i] for i in tk],fontsize=8)
ax[2].set_xlabel('그 바이러스가 처음 들어온 시점'); ax[2].set_ylabel('감염시킨 사람 수 (백만 명)',fontsize=9)
ax[2].legend(fontsize=9,loc='upper center'); ax[2].set_title('(다) 언제 들어오느냐가 성패를 가른다',fontsize=10.5,loc='left',color=NAVY)
ax[2].grid(alpha=.28); ax[2].spines[['top','right']].set_visible(False)
# (라)
ks=['0.0_1.0','0.3_1.0','0.6_1.0','1.0_1.0','0.6_2.0']
nm=['대가가 없다면','대가가 작다면','대가가 보통이면','대가가 크다면','대가가 처음엔 작다면']
dy=[0,0,-0.04,0.04,0]
for kk,n,d in zip(ks,nm,dy):
    o=O['OUT'][kk]
    ax[3].scatter(o['eps'],o['tau']+d,s=150,zorder=3,edgecolor='white',linewidth=1,
        label=f"{n} → 비껴가는 정도 {o['eps']:.2f}, 퍼지는 정도 {o['tau']:.2f}")
ys=[1.33,1.24,1.15,1.06,1.33]
for (n,e),yy in zip(O['OBS'].items(),ys):
    ax[3].axvline(e,ls=':',color='#999',lw=1)
    ax[3].annotate(n,(e,yy),fontsize=7.4,color='#444',ha='right' if e>0.6 else 'left',
                   xytext=(-4 if e>0.6 else 4,0),textcoords='offset points',va='center')
ax[3].set_xlim(-0.05,1.12); ax[3].set_ylim(0.3,1.55)
ax[3].set_xlabel('기존 면역을 비껴가는 정도'); ax[3].set_ylabel('잘 퍼지는 정도',fontsize=9)
ax[3].legend(fontsize=7.8,loc='lower left',framealpha=.95,title='대가를 고려했을 때 가장 유리한 조합',title_fontsize=8.2)
ax[3].set_title('(라) 면역을 비껴가려면 퍼지는 속도를 일부 포기해야 한다면?',fontsize=10.5,loc='left',color=NAVY)
ax[3].grid(alpha=.28); ax[3].spines[['top','right']].set_visible(False)
ax[3].text(0.30,1.44,'세로 점선 = 실제로 관찰된 바이러스들이 기존 면역을 비껴간 정도',fontsize=8.1,color='#444',va='center',
           bbox=dict(boxstyle='round,pad=0.35',fc='#f7f7f7',ec='#ccc'))
fig.text(0.5,0.022,'※ 바이러스를 두 가지 성질(퍼지는 속도, 기존 면역을 비껴가는 정도)로만 나타낸 계산이며, 어떤 바이러스가 실제로 생겨날지는 다루지 않는다.',
         ha='center',fontsize=8.6,color='#666')
fig.savefig('fig/evo_fitness.png',dpi=125)
print('ok')
