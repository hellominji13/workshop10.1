"""코로나19 시나리오 전망: C1(신규 변이 없음), C2(2026-50 신규 변이 50%, 중화 40%↓), REP(변이 교체 포아송)."""
import numpy as np, pickle, sys, common as c, covid as cv, fit_covid as fc
QL=np.array([0.025,0.10,0.25,0.50,0.75,0.90,0.975])
FIT=pickle.load(open(sys.argv[1] if len(sys.argv)>1 else 'covid_fit_best.pkl','rb'))
fc.SEAS=FIT['seas']
x0=FIT['x']; J=FIT['jac']; s2=2*FIT['cost']/(len(FIT['fun'])-len(x0))
COVX=np.linalg.pinv(J.T@J)*s2*9.0
ALLW=c.week_range(202401,202735); REPORT=c.week_range(202640,202735); i40=ALLW.index(202640)
E_FIT=np.array([dict(zip(fc.P,x0))['e_'+k] for k in fc.FAM])
E_WAVE=E_FIT[E_FIT>np.median(E_FIT)]            # 파동을 만든 계통군의 회피 크기
def logistic_share(center,width=3.0):
    """새 변이 점유율: center 주에 50%, 로지스틱 성장(배가 약 2주) → 주별 증가분"""
    idx=np.arange(len(ALLW)); ci=ALLW.index(center)
    p=1/(1+np.exp(-(idx-ci)/width)); return np.diff(np.r_[0,p])
def vac65(yw):   # 코로나19 2026-27 접종: 65세 이상, 2026-42주부터 6주, 접종률 45%·감염예방 35% 가정
    w=yw%100
    if 202642<=yw<=202647: v=np.zeros(6); v[5]=0.45*0.35/6; return v
    return None
def run(scn,N=1000,seed=0):
    rng=np.random.default_rng(seed); X=rng.multivariate_normal(x0,COVX/9.0,N)
    # 현재 파동(PQ.16.1.1) 회피 크기는 과거 적합에서 식별되지 않음 → 사전 U(0,1) 후 nowcast로 갱신
    X[:,fc.P.index('e_PQ.16.1.1')]=rng.uniform(0,1,N); X=np.clip(X,fc.LB,fc.UB)
    H=np.zeros((N,len(ALLW)))
    for j in range(N):
        extra={}
        if scn=='C2':
            e=rng.choice(E_WAVE)*rng.uniform(0.9,1.3); d=logistic_share(202650)
            for t,yw in enumerate(ALLW):
                if d[t]>1e-4: extra[yw]=e*d[t]
        if scn=='REP':
            rate=6/ (26/12)          # 2024-07~2026-08: 계통군 교체 6회 / 26개월
            n=rng.poisson(rate*(49/52))
            for _ in range(n):
                ctr=ALLW[rng.integers(i40+4,len(ALLW))]; e=rng.choice(E_FIT); d=logistic_share(ctr)
                for t,yw in enumerate(ALLW):
                    if d[t]>1e-4: extra[yw]=1-(1-extra.get(yw,0))*(1-e*d[t])
        u=np.zeros(len(ALLW))
        for t in range(i40,len(ALLW)): u[t]=0.8*u[t-1]+rng.normal(0,0.05)
        h,inc,st=fc.run(X[j],FIT['vs'],FIT['hr'],weeks=ALLW,qmult=np.exp(u),vac=vac65,extra=extra)
        H[j]=h*np.exp(rng.normal(0,0.12,len(ALLW)))
    # nowcast: 2026-27~39주 관측으로 중요도 가중 후 재표집 (기점까지의 정보만 사용)
    ow=c.week_range(202627,202639); oi=[ALLW.index(w) for w in ow]; ob=fc.D.loc[ow,'ARI'].values
    ll=-0.5*(((np.log(H[:,oi]+10)-np.log(ob+10))/0.3)**2).sum(1)
    wt=np.exp(ll-ll.max()); wt/=wt.sum(); idx=rng.choice(N,N,p=wt)
    print('  ESS',round(1/np.sum(wt**2),1))
    return H[idx]
def summarize(H):
    i=[ALLW.index(w) for w in REPORT]; x=H[:,i]
    return dict(q=np.quantile(x,QL,axis=0),pkw=np.quantile(x.argmax(1)+1,QL),pkv=np.quantile(x.max(1),QL),cum=np.quantile(x.sum(1),QL))
if __name__=='__main__':
    out={}
    for k,s in enumerate(['C1','C2','REP']):
        H=run(s,N=2000,seed=30+k); out[s]=H; sm=summarize(H)
        print(s,'pkw',sm['pkw'][[1,3,5]],'pk',sm['pkv'][[1,3,5]].round(0),'cum',sm['cum'][[1,3,5]].round(0))
        print('  med 40-52',np.median(H[:,i40:i40+13],0).round(0))
    pickle.dump(dict(out=out,ALLW=ALLW),open('covid_scen.pkl','wb'))
