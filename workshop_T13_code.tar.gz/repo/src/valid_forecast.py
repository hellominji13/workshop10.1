"""후향 검증 2단계: 기점(38주)까지 자료로 nowcast → 절기 끝(35주)까지 전망 → WIS. 2026 전망과 같은 파이프라인."""
import numpy as np, pandas as pd, pickle, sys, common as c, flu, fit_flu as ff
import os
PNOISE=float(os.environ.get("PNOISE","0.05"))
QL=np.array([0.025,0.10,0.25,0.50,0.75,0.90,0.975])
def wis(q,y):
    m=q[3]; s=0.5*abs(y-m)
    for lo,hi,a in [(0,6,0.05),(1,5,0.2),(2,4,0.5)]:
        l,u=q[lo],q[hi]; s+=a/2*((u-l)+2/a*(l-y)*(y<l)+2/a*(y-u)*(y>u))
    return s/3.5
def run(T,N0=4000,N=1000,seed=7):
    V=pickle.load(open(f'valid_{T}.pkl','rb')); flu.PI=V['PI']; O=V['origin']; NS=len(V['train'])
    g0=dict(zip(ff.G,V['x'][:ff.NG])); loc=V['x'][ff.NG:].reshape(NS,3,2)
    rng=np.random.default_rng(seed); F=ff.F
    W=c.week_range(T*100+36,(T+1)*100+35); iO=W.index(O); FW=W[iO+1:]
    # 비독감 기저: 기점 이전 자료만으로 회귀
    tr=F[((F.index<202010)|(F.index>=202236))&(F.index<T*100+36)]
    pl=tr.ILI*tr.pos/100; t=2*np.pi*(tr.index%100)/52.18
    Xb=np.c_[pl,np.ones(len(tr)),np.cos(t),np.sin(t),np.cos(2*t),np.sin(2*t)]; b=np.linalg.lstsq(Xb,tr.ILI.values,rcond=None)[0]
    base=Xb[:,1:]@b[1:]; an=np.log(np.clip(tr.ILI.values-b[0]*pl,0.5,None))-np.log(np.clip(base,0.5,None))
    rho=np.corrcoef(an[1:],an[:-1])[0,1]; sda=np.std(an[1:]-rho*an[:-1])
    bl=lambda yw: b[1]+b[2]*np.cos(2*np.pi*(yw%100)/52.18)+b[3]*np.sin(2*np.pi*(yw%100)/52.18)+b[4]*np.cos(4*np.pi*(yw%100)/52.18)+b[5]*np.sin(4*np.pi*(yw%100)/52.18)
    GV=np.clip(rng.multivariate_normal(V['x'][:ff.NG],V['covg'],N0),ff.LB[:ff.NG],ff.UB[:ff.NG])
    OBSW=W[:iO+1]; obs=F.loc[OBSW,['H1p','H3p','Bp']].values
    ili=np.zeros((N0,len(W))); ll=np.zeros(N0)
    for j in range(N0):
        g=dict(zip(ff.G,GV[j])); sig=ff.sigma(g)
        S0=np.zeros((3,6)); I0=np.zeros((3,6))
        for k in range(3):
            i=rng.integers(NS); ls=loc[i,k,0]+rng.normal(0,0.3); lI=loc[i,k,1]+rng.normal(0,1.5)
            S0[k]=np.minimum(sig[k]/(1+np.exp(-ls)),0.995); I0[k]=np.exp(lI)
        u=np.zeros(len(W))
        for tt in range(iO+1,len(W)): u[tt]=0.8*u[tt-1]+rng.normal(0,PNOISE)
        qm=g['R0']/flu.R0*np.exp(rng.normal(0,0.15))*np.exp(u)
        inc,_=flu.simulate(W,S0,I0,g['theta'],g['vac_school'],g['hol_red'],qmult=qm)
        tot,_=flu.obs_ili(inc,np.exp(g['logkappa'])); hol=np.array([g['hrep'] if yw in c.HOLIDAY else 1 for yw in W])
        ll[j]=-0.5*np.sum(((np.sqrt(tot[:iO+1]*hol[:iO+1,None])-np.sqrt(obs))/0.35)**2)
        oO=F.loc[O]; a=np.log(max(oO.ILI/hol[iO]-1.66*oO.ILI*oO.pos/100,0.5)/bl(O)); bg=np.zeros(len(W))
        for tt,yw in enumerate(W):
            if tt>iO: a=rho*a+rng.normal(0,sda)
            bg[tt]=bl(yw)*np.exp(a if tt>=iO else 0)
        ili[j]=hol*(1.66*tot.sum(1)+bg)*np.exp(rng.normal(0,0.08,len(W)))
    w=np.exp(ll-ll.max()); w/=w.sum(); idx=rng.choice(N0,N,p=w); ili=ili[idx]
    fi=list(range(iO+1,len(W))); q=np.quantile(ili[:,fi],QL,axis=0); y=F.loc[FW,'ILI'].values
    S=np.array([wis(q[:,k],y[k]) for k in range(len(FW))])
    # 기준모형(문제지 부록 B): 중앙=기점값, 분위수=기점값+과거 h주 변화량 경험분위수(대칭화), 0 절단
    hist=F[((F.index<202010)|(F.index>=202236))&(F.index<=O)].ILI.values
    qb=np.zeros((7,len(FW)))
    for h in range(1,len(FW)+1):
        d=hist[h:]-hist[:-h]; d=np.r_[d,-d]; qb[:,h-1]=np.maximum(F.loc[O,'ILI']+np.quantile(d,QL),0)
    SB=np.array([wis(qb[:,k],y[k]) for k in range(len(FW))])
    return dict(T=T,W=W,FW=FW,q=q,y=y,wis=S,wis_base=SB,ess=1/np.sum(w**2),ili=ili,iO=iO,
                pk_obs=y.max(),pk_q=np.quantile(ili[:,fi].max(1),[0.025,0.5,0.975]),cover50=np.mean((y>=q[2])&(y<=q[4])),cover95=np.mean((y>=q[0])&(y<=q[6])))
if __name__=='__main__':
    R={}
    for T in [2023,2024,2025]:
        r=run(T); R[T]=r
        print(T,'ESS',round(r['ess'],1),'WIS',r['wis'].mean().round(2),'base',r['wis_base'].mean().round(2),'peak obs',r['pk_obs'],'pred',r['pk_q'].round(0),'cov50',round(r['cover50'],2),'cov95',round(r['cover95'],2))
    print('mean WIS',np.mean([R[T]['wis'].mean() for T in R]).round(2),'baseline',np.mean([R[T]['wis_base'].mean() for T in R]).round(2))
    pickle.dump(R,open(f'valid_results_{PNOISE}.pkl','wb'))
