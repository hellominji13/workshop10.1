import numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c
plt.rcParams['font.family']='Noto Sans CJK JP'; plt.rcParams['axes.unicode_minus']=False
G='#2a9d5c'; P='#7b3fbf'
fig,ax=plt.subplots(figsize=(13,4.6))
# 계절성 코로나바이러스 (왼쪽 축)
h=pd.read_csv(c.D+'hcov.csv',header=None,names=['y','w','n','x']); h['t']=h.y+(h.w-1)/52.18
ax.plot(h.t,h.n,color=G,lw=1.1,marker='o',ms=1.8,label='계절성 코로나바이러스(hCoV) 주간 검출 — 왼쪽 축')
ax.set_ylabel('계절성 코로나바이러스 주간 검출 (건)',color=G); ax.tick_params(axis='y',colors=G)
ax.set_ylim(0,h.n.max()*1.15)
# 코로나19 입원 (오른쪽 축)
ax2=ax.twinx()
d=c.load_covid(); W=list(d.index)
t=np.array([c.week_start(w).year+(c.week_start(w).timetuple().tm_yday-1)/365.25 for w in W])
ax2.plot(t,d.ARI.values,color=P,lw=1.4,marker='o',ms=2,label='코로나19 입원환자 수 — 오른쪽 축')
ax2.set_ylabel('코로나19 주간 입원환자 (명)',color=P); ax2.tick_params(axis='y',colors=P)
ax2.set_ylim(0,d.ARI.max()*1.15)
# 방역 기간 음영
ax.axvspan(2020.2,2022.4,color='gray',alpha=.13,zorder=0)
ax.text(2020.33,h.n.max()*1.0,'코로나19\n방역적 중재기',fontsize=8.5,va='top')
# 자료 시작 표시
ax.axvline(2024.0,color=P,ls='--',lw=1,alpha=.6)
ax.annotate('코로나19 입원 감시자료 시작 (2024년 1주)',xy=(2024.0,h.n.max()*0.92),xytext=(2021.4,h.n.max()*1.03),
            fontsize=8,color=P,ha='left',va='center',arrowprops=dict(arrowstyle='->',color=P,lw=.9))
# 변이 계통 우세 시기
ev={'JN.1':2024.04,'KP.3':2024.54,'XEC/LP.8.1':2025.10,'NB.1.8.1':2025.42,'BA.3.2':2026.27,'PQ.16.1.1':2026.62}
for k,(nm,xx) in enumerate(ev.items()):
    ax.axvline(xx,ls=':',color='#999',lw=.8)
    ax.text(xx,h.n.max()*(0.72 if k%2==0 else 0.50),nm,fontsize=7,rotation=90,va='top',ha='right',color='#555')
ax.set_xticks(range(2015,2028)); ax.set_xlim(2015,2027); ax.grid(alpha=.22)
ax.set_title('코로나19 및 계절성 코로나바이러스 주간 감시자료 (2015–2026)',fontsize=12)
l1,n1=ax.get_legend_handles_labels(); l2,n2=ax2.get_legend_handles_labels()
ax.legend(l1+l2,n1+n2,fontsize=8.5,loc='upper left',framealpha=.92)
fig.text(0.012,0.012,'※ 2020~2023년 코로나19 주간 입원 감시자료는 제공 자료에 포함되어 있지 않음. 점선: 변이 계통 우세 시기 · 회색 음영: 코로나19 방역적 중재기',fontsize=7.5,color='#666')
fig.tight_layout(rect=[0,0.035,1,1]); fig.savefig('fig/covid_series.png',dpi=130)
print('ok')
