"""RSV: 연령(6) SEIRS, 독감·코로나와 같은 공통 접촉행렬 C(t).
β(t) = q·[1 + a·cos(2π(t−φ)/52.18)]·sus_a·C(t)·NPI(t)
잠복 4일(Lessler 2009: 4.4일), 감염기간 7일(바이러스 배출 ~1주), 재감염 가능(면역 소실 추정, 사전 ~1년)
관측: 주간 RSV 검출 건수 = η·Σ_a d_a·N_a·감염_a  (d: 연령별 검사·검출 상대가중 — 영유아 중심 검사 관행 반영)"""
import numpy as np, pandas as pd, common as c
from scipy.optimize import least_squares, differential_evolution
LAT,INF=4.0,7.0
SUS=np.array([1.0,0.6,0.5,0.5,0.5,0.6])      # 영유아 최고, 성인은 재감염 감수성 낮음 (Hall 1991 재감염 연구 범위)
DET=np.array([1.0,0.15,0.05,0.03,0.08,0.4])  # 검출 상대가중: 검사가 영유아·고령 입원에 집중
r=pd.read_csv(c.D+'rsv.csv',header=None,names=['y','w','n','x']); r['yw']=r.y*100+r.w
OBS=r.set_index('yw').n.astype(float)
W=[w for w in c.week_range(201501,202552)]
OBS=OBS.reindex(W).interpolate().values
NPI_W=(202010,202220)
def sim(p,weeks,state=None,ret_state=False):
    R0,amp,phi,wane,npi,leta,lI,leta2,dphi=p
    C0=c.contact(202645,1,1); q=R0/np.max(np.abs(np.linalg.eigvals(SUS[:,None]*C0*INF)))
    if state is None:
        S=np.full(6,0.3); I=np.full(6,np.exp(lI)); E=I*LAT/INF; R=1-S-E-I
    else: S,E,I,R=[x.copy() for x in state]
    inc=np.zeros((len(weeks),6)); om=1/wane
    for t,yw in enumerate(weeks):
        tt=(c.week_start(yw)-c.week_start(201501)).days/7
        ph=phi+(dphi if yw>=202236 else 0.0)   # 코로나19 이후 계절 시점 이동(post-pandemic shift)
        f=max(1+amp*np.cos(2*np.pi*(tt-ph)/52.18),0.05)
        m=npi if NPI_W[0]<=yw<=NPI_W[1] else 1.0
        B=q*f*m*SUS[:,None]*c.contact(yw,0.6,0.35)
        for d in range(7):
            nE=(B@I)*S; S=S-nE+om*R; E=E+nE-E/LAT; I=I+E/LAT-I/INF; R=R+I/INF-om*R
            # 출생·사망 근사: 0-6세 감수성 보충 (연 1/7 교체)
            S[0]+= (1/(7*365))*(1-S[0])
            inc[t]+=E/LAT
    sc=np.array([np.exp(leta2) if yw>=202236 else np.exp(leta) for yw in weeks])   # 코로나19 이후 검사 체계 변화에 따른 검출 척도
    h=sc*(inc*c.N*DET).sum(1)
    return (h,(S,E,I,R)) if ret_state else h
def resid(p):
    h=sim(p,W); return np.log(h+20)-np.log(OBS+20)
LB=[1.05,0.05,-10,90,0.2,-14,-14,-14,-8]; UB=[4.0,0.6,10,730,1.0,-2,-4,-2,8]
if __name__=='__main__':
    import pickle
    obj=lambda p: float(np.sum(resid(p)**2))
    de=differential_evolution(obj,list(zip(LB,UB)),seed=3,maxiter=70,popsize=10,tol=1e-7,polish=False)
    sol=least_squares(resid,de.x,bounds=(LB,UB),max_nfev=200)
    h=sim(sol.x,W); R2=1-((OBS-h)**2).sum()/((OBS-OBS.mean())**2).sum()
    print(dict(zip(['R0','amp','phase','wane','npi','logeta','logI0','logeta2','dphase'],sol.x.round(3))),'R2',R2)
    pickle.dump(dict(x=sol.x,jac=sol.jac,fun=sol.fun),open('rsv_fit.pkl','wb'))
