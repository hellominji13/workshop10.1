import numpy as np, pandas as pd, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, fit_covid as fc
plt.rcParams['font.family']='Noto Sans CJK JP'
x=pd.read_excel(c.D+'variant.xlsx',header=None); yrs=x.iloc[0,1:].ffill(); mon=x.iloc[1,1:]
v=x.iloc[2:,1:].astype(float).fillna(0); v.index=x.iloc[2:,0]; v.columns=[f'{str(y)[2:4]}.{str(m).replace("월","").zfill(2)}' for y,m in zip(yrs,mon)]
v=v.loc[:,'24.01':]; fam={**fc.FAM,'JN.1':['JN.1','JN.1.16']}; order=['JN.1','KP','XEC','LP.8.1','NB','BA.3.2','PQ.16.1.1']
D=pd.DataFrame({f:v.loc[fam[f]].sum(0) for f in order}); D['기타']=100-D.sum(1)
f=pickle.load(open('covid_fit_best.pkl','rb')); e=dict(zip(fc.P,f['x']))
fig,ax=plt.subplots(1,2,figsize=(15,4),gridspec_kw=dict(width_ratios=[2,1]))
cols=['#bbbbbb','#e0a040','#9ecae1','#4292c6','#7b3fbf','#2a9d5c','#d1495b','#eeeeee']
ax[0].stackplot(range(len(D)),D.T.values,labels=D.columns,colors=cols); ax[0].set_xticks(range(0,len(D),3)); ax[0].set_xticklabels(D.index[::3]); ax[0].set_ylim(0,100)
ax[0].legend(fontsize=8,ncol=4,loc='upper left',bbox_to_anchor=(0,-0.1)); ax[0].set_title('코로나19 변이 계통군 월별 점유율 (%), 2024.1~2026.8')
ks=['KP','XEC','LP.8.1','NB','BA.3.2','PQ.16.1.1']; ev=[e['e_'+k] for k in ks]
ax[1].bar(range(6),ev,color=cols[1:7]); ax[1].set_xticks(range(6)); ax[1].set_xticklabels(ks,fontsize=9,rotation=20)
for i,val in enumerate(ev): ax[1].text(i,val+0.02,f'{val:.2f}',ha='center',fontsize=9)
ax[1].set_ylim(0,1.15); ax[1].set_title('계통군별 추정 e: 우세화 시 기존 면역자 중\n새 계통에 다시 감염될 수 있게 되는 비율',fontsize=10)
fig.tight_layout(); fig.savefig('fig/variants.png',dpi=120)
