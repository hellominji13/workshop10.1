import numpy as np, pickle, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, forecast_flu as fc
plt.rcParams['font.family']='Noto Sans CJK JP'
out=pickle.load(open('flu_scen.pkl','rb'))
hist=c.week_range(202627,202639); F=fc.ff.F
fig,ax=plt.subplots(1,3,figsize=(18,4.8),sharey=True)
colr={'F1':'#2a6fdb','F2':'#e0542e','REP':'#444444'}
for k,s in enumerate(['REP','F1','F2']):
    o=out[s]; q=np.quantile(o['ili'],[.025,.1,.25,.5,.75,.9,.975],axis=0); x=np.arange(len(fc.ALLW))
    ax[k].fill_between(x[x>=fc.ALLW.index(202639)],q[0][x>=fc.ALLW.index(202639)],q[6][x>=fc.ALLW.index(202639)],color=colr[s],alpha=.12,label='95%'); ax[k].fill_between(x[x>=fc.ALLW.index(202639)],q[1][x>=fc.ALLW.index(202639)],q[5][x>=fc.ALLW.index(202639)],color=colr[s],alpha=.2,label='80%'); ax[k].fill_between(x[x>=fc.ALLW.index(202639)],q[2][x>=fc.ALLW.index(202639)],q[4][x>=fc.ALLW.index(202639)],color=colr[s],alpha=.3,label='50%')
    m=x>=fc.ALLW.index(202639); ax[k].plot(x[m],q[3][m],color=colr[s],lw=2,label="중앙값")
    ax[k].plot([fc.ALLW.index(w) for w in hist],F.loc[hist,'ILI'],'ko',ms=3.5,label='관측(300개소)')
    ax[k].axhline(12.9,ls='--',color='gray',lw=1); ax[k].text(1,14,'유행기준 12.9',fontsize=8,color='gray')
    ax[k].axvline(fc.ALLW.index(202639),color='k',lw=.8)
    tk=[fc.ALLW.index(w) for w in [202627,202640,202648,202701,202710,202720,202730]]; ax[k].set_xticks(tk); ax[k].set_xticklabels(['26-27','26-40','26-48','27-01','27-10','27-20','27-30'],fontsize=8)
    ax[k].set_title({'REP':'대표 전망 (REP)','F1':'F1: 신규 아형 없음 (H1만)','F2':'F2: 48주 전후 H3 유입'}[s])
ax[0].set_ylabel('의사환자분율 (외래 1,000명당)'); ax[0].legend(fontsize=8); fig.tight_layout(); fig.savefig('fig/flu_forecast.png',dpi=110)
