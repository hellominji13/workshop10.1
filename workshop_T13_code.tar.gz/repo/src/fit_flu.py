import numpy as np, pandas as pd, common as c, flu, pickle
from scipy.optimize import least_squares
F=c.load_flu(); AGE=pd.read_pickle('agedata.pkl')
SEASONS=[(201636,201735),(201736,201835),(201836,201935),(201936,202009),
         (202236,202335),(202336,202435),(202436,202535),(202536,202635),(202626,202639)]
SNAME=['2016-17','2017-18','2018-19','2019-20','2022-23','2023-24','2024-25','2025-26','2026-27']
NS=len(SEASONS)
CHILD=np.array([1,1,1,0,0,0.]); OLD=np.array([0,0,0,0,0.5,1])
G=['R0','theta','vac_school','hol_red','logkappa','hrep','logkA']+[f'{p}_{k}' for k in flu.SUB for p in ('ach','aold')]
NG=len(G)
def unpack(x):
    g=dict(zip(G,x[:NG])); loc=x[NG:].reshape(NS,3,2); return g,loc
def sigma(g):
    return np.array([np.exp(g[f'ach_{k}']*CHILD+g[f'aold_{k}']*OLD) for k in flu.SUB])
def run_season(i,g,loc,cov=flu.COV):
    a,b=SEASONS[i]; w=c.week_range(a,b)
    sig=sigma(g); s=1/(1+np.exp(-loc[i,:,0]))
    S0=np.minimum(s[:,None]*sig,0.995); I0=np.exp(loc[i,:,1])[:,None]*np.ones(6)
    if i==NS-1: S0[1:]=0.3; I0[1:]=0
    inc,st=flu.simulate(w,S0,I0,g['theta'],g['vac_school'],g['hol_red'],cov=cov,qmult=np.full(len(w),g['R0']/flu.R0))
    return w,inc,st
def resid(x,ret=False):
    g,loc=unpack(x); out=[]; keep={}
    kap=np.exp(g['logkappa'])
    for i in range(NS):
        w,inc,st=run_season(i,g,loc)
        tot,age=flu.obs_ili(inc,kap)
        hol=np.array([g['hrep'] if yw in c.HOLIDAY else 1.0 for yw in w])
        tot=tot*hol[:,None]
        obs=F.loc[w,['H1p','H3p','Bp']].values
        r=(np.sqrt(tot)-np.sqrt(obs)); r[np.isnan(r)]=0
        if i==NS-1: r=r[:,:1]*2.0           # 현재 절기는 H1만, 가중 2
        out.append(r.ravel()); keep[i]=(w,inc,tot,age)
        # 연령별 자료
        A=AGE[AGE.yw.isin(w)]
        if len(A):
            idx=[w.index(y) for y in A.yw]
            m=age[idx]*np.exp(g['logkA'])*hol[idx][:,None]
            o=A[c.AGES].values*F.loc[A.yw,'pos'].values[:,None]/100
            out.append(0.5*(np.sqrt(m)-np.sqrt(o)).ravel())
    # 약한 사전: 문헌 기반 범위로 정칙화 (θ: 습도 1g/m³당 β 감소 0~15%, 방학 학교접촉 잔존 0~1)
    pri=[(g['theta']-0.05)/0.05,(g['vac_school']-0.3)/0.3,(g['hol_red']-0.5)/0.3,(g['hrep']-1.3)/0.3]
    out.append(np.array(pri))
    r=np.concatenate(out)
    return (r,keep) if ret else r
def x0():
    g=[1.6,0.05,0.3,0.5,np.log(flu.KAPPA),1.3,0.0]+[0.3,-0.3]*3
    loc=np.zeros((NS,3,2)); loc[:,:,0]=0.8; loc[:,:,1]=-12
    return np.r_[g,loc.ravel()]
LB=np.r_[[1.1,-0.2,0,0.05,np.log(flu.KAPPA)-1e-6,0.8,-3]+[-2,-3]*3, np.tile([-4,-30],NS*3)]
UB=np.r_[[4.0,0.3,1,1.0,np.log(flu.KAPPA)+1e-6,2.5,3]+[2,2]*3, np.tile([4,-4],NS*3)]
if __name__=='__main__':
    # 희소 야코비안: 절기 모수는 자기 절기 잔차만
    r0,keep=resid(x0(),True)
    sizes=[];  # 잔차 블록 크기 재구성
    g,loc=unpack(x0()); blocks=[]
    for i in range(NS):
        w=c.week_range(*SEASONS[i]); n=len(w)*(1 if i==NS-1 else 3)
        A=AGE[AGE.yw.isin(w)]; n+=len(A)*6; blocks.append(n)
    sp=np.zeros((len(r0),len(r0) and len(x0())),dtype=int); sp[:,:NG]=1; st=0
    for i,n in enumerate(blocks):
        sp[st:st+n,NG+i*6:NG+(i+1)*6]=1; st+=n
    sol=least_squares(resid,x0(),bounds=(LB,UB),jac_sparsity=sp,x_scale='jac',verbose=1,max_nfev=300)
    pickle.dump(dict(x=sol.x,jac=sol.jac.toarray() if hasattr(sol.jac,'toarray') else sol.jac,fun=sol.fun),open(__import__('os').environ.get('FITOUT','flu_fit.pkl'),'wb'))
    g,loc=unpack(sol.x); print({k:round(v,3) for k,v in g.items()})
    print('s=',np.round(1/(1+np.exp(-loc[:,:,0])),2)); print('logI0',loc[:,:,1].round(1))
