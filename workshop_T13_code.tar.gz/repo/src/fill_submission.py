"""답안 제출 양식(T13) 채우기. 템플릿의 노란 칸만 값으로 덮어쓴다."""
import numpy as np, pickle, openpyxl, sys, common as c, forecast_flu as fcf
QL=[0.025,0.10,0.25,0.50,0.75,0.90,0.975]
SRC=sys.argv[1] if len(sys.argv)>1 else '/home/claude/T13.xlsx'
DST=sys.argv[2] if len(sys.argv)>2 else '/mnt/user-data/outputs/submission_T13.xlsx'
FL=pickle.load(open('flu_scen.pkl','rb')); CV=pickle.load(open('covid_scen.pkl','rb')); RS=pickle.load(open('rsv_fc.pkl','rb'))
R=fcf.REPORT; fi=[fcf.ALLW.index(w) for w in R]; ci=[CV['ALLW'].index(w) for w in R]
def mono(q): return np.maximum.accumulate(np.maximum(q,0))
S={}                                        # (target,scenario) -> (49,7)
for s in ['REP','F1','F2']:
    S[('ili',s)]=np.quantile(FL[s]['ili'][:,fi],QL,axis=0).T
    S[('flu_hosp',s)]=np.quantile(FL[s]['hosp'][:,fi],QL,axis=0).T
for s in ['REP','C1','C2']:
    S[('covid_ari',s)]=np.quantile(CV['out'][s][:,ci],QL,axis=0).T
SING={}                                     # (target_single,scenario) -> 7
for s in ['REP','F1','F2']:
    for tg,arr in [('ili',FL[s]['ili'][:,fi]),('flu_hosp',FL[s]['hosp'][:,fi])]:
        SING[(tg+'_peak_week',s)]=np.quantile(arr.argmax(1)+1,QL)
        SING[(tg+'_peak_value',s)]=np.quantile(arr.max(1),QL)
        SING[(tg+'_cum_total',s)]=np.quantile(arr.sum(1),QL)
for s in ['REP','C1','C2']:
    arr=CV['out'][s][:,ci]
    SING[('covid_ari_peak_week',s)]=np.quantile(arr.argmax(1)+1,QL)
    SING[('covid_ari_peak_value',s)]=np.quantile(arr.max(1),QL)
    SING[('covid_ari_cum_total',s)]=np.quantile(arr.sum(1),QL)
wb=openpyxl.load_workbook(SRC)
# --- 시트 2: 1C (기점 2026-39 → 40~44주). 문제 2 모형의 ILI 분위수 ---
ws=wb['2.문제1_단기예측']; q_ili=S[('ili','REP')]
for i,row in enumerate(range(27,32)):
    if ws.cell(row,1).value=='1C':
        for j,v in enumerate(mono(q_ili[i])): ws.cell(row,6+j).value=round(float(v),3)
# --- 시트 3: 주간 시계열 ---
ws=wb['3.문제2_시계열']
for row in range(2,ws.max_row+1):
    tg,sc,wi=ws.cell(row,1).value,ws.cell(row,2).value,ws.cell(row,3).value
    if (tg,sc) in S and wi:
        for j,v in enumerate(mono(S[(tg,sc)][int(wi)-1])): ws.cell(row,5+j).value=round(float(v),3)
# --- 시트 4: 단일값 ---
ws=wb['4.문제2_단일값']
for row in range(2,ws.max_row+1):
    tg,sc=ws.cell(row,1).value,ws.cell(row,2).value
    if (tg,sc) in SING:
        v=mono(SING[(tg,sc)])
        for j,x in enumerate(v):
            ws.cell(row,4+j).value=int(round(x)) if tg.endswith('peak_week') else round(float(x),3)
# --- 시트 6: 3-A RSV ---
ws=wb['6.문제3']
info={3:'3-A',4:'RSV (호흡기세포융합바이러스)',
      5:'질병관리청 감염병포털 호흡기바이러스 통합감시 주간 검출 건수 (2015~2025), 파일명 2015-2025rsv.csv',
      6:'task3/task3_RSV_and_variant_fitness.pdf'}
for r,v in info.items(): ws.cell(r,2).value=v
FWs=[w for w in RS['FW'] if 202640<=w<=202716]; H=RS['H'][:,[RS['FW'].index(w) for w in FWs]]
Q=np.quantile(H,QL,axis=0).T
for row in range(10,ws.max_row+1):
    wi=ws.cell(row,3).value
    if wi:
        ws.cell(row,1).value='rsv_detections'
        for j,v in enumerate(mono(Q[int(wi)-1])): ws.cell(row,5+j).value=round(float(v),1)
# --- 시트 7: 메타데이터 ---
M={
'모형 구조':'문제 2·3: 연령 6군(0-6/7-12/13-18/19-49/50-64/65+) 결정론 SEIR. 인플루엔자는 아형 3개(A(H1N1)pdm09·A(H3N2)·B) × 연령, 코로나19는 연령 SEIRS, RSV는 연령 SEIRS. 세 병원체가 동일한 연령별 접촉행렬 C(t)(가정·학교·직장·기타 4층, 학사일정·명절 반영)를 공유하며, 병원체별로 전파확률·연령 감수성·계절성·면역 동역학만 다르다. 아형 간 차이는 전파력이 아니라 절기 시작 시점의 연령별 초기 감수성 인구 비율 S0로 반영하고, 국가예방접종(연령별 접종률 × 아형별 백신효과 × 접종 일정)이 S0를 감소시킨다. 관측식: ILI+ = 1000·κ·Σ_a π_a·(주간 신규감염_a/N_a), ILI = 1.66·ΣILI+ + 비인플루엔자 기저(연 2회 조화항 + AR(1)), 입원 = η·Σ_a r_a·N_a·주간 신규감염_a. 문제 1(단기예측)은 별도 모형(SIR beta regression + GBM)을 사용하였다.',
'추정 방법':'3단계. ① 과거 8개 절기(2016-17~2025-26, 코로나19 방역기 제외) 아형별 ILI+와 연령별 ILI+에 대한 제곱근 척도 비선형최소제곱(scipy least_squares, 희소 야코비안). 전역 모수 12개 + 절기·아형별 2개(감수성 수준 s, 초기 감염 I0). 관측 척도 κ는 문헌값 0.58로 고정. ② 2026-26~39주 A(H1N1)pdm09 ILI+ 14개 관측으로 표본-중요도-재표집(SIR) nowcast (사전표본 2만, 유효표본 61). ③ 사후표본별 결정론 시뮬레이션 + 과정잡음 AR(1)(ρ=0.8, sd=0.05)과 관측오차로 분위수 산출. 코로나19는 차분진화 후 최소제곱, 공통 접촉 모수(방학 중 학교 접촉 잔존율 v, 명절 잔존율 h)는 두 병원체 프로파일 로그우도 합으로 공동 추정. 신뢰구간은 야코비안 근사 공분산에 잔차 자기상관 보정계수 (1+ρ)/(1−ρ)=9를 곱함.',
'입력 자료':'제공 자료: 인플루엔자 학습자료(2016-01~2026-39, ILI·ARI·아형별 검출률), 코로나19 학습자료(2024-01~2026-39, ARI), 코로나19 변이 점유율(2020.1~2026.8 월별), 연령별 의사환자분율(2017-18·2018-19·2019-20·2024-25·2025-26절기만 사용). 외부 자료: 기상청 서울 절대습도(일별, 2016-01-01~2026-09-29, 기점까지만 사용), 질병관리청·국민건강보험공단 국가 인플루엔자 연례보고서(2026.4) — 연령별 접종률·입원 연령 분포·의료이용 건수·건당 진료비, 감염병포털 호흡기바이러스 통합감시 RSV 주간 검출(2015~2025), 통계청 주민등록 연령별 인구. 문헌 고정값은 기술보고서 표 4 참조. 미사용: 검색량, hMPV·계절성 코로나바이러스, 코로나19 기초접종 통계(2021~2023).',
'기점 이후 정보 차단 방법':'common.py의 ah_at()은 주차 인덱스로만 습도를 조회하며, 후향 검증 스크립트(valid_fit.py)는 대상 절기 기점 이전에 종료된 절기만 SEASONS에서 선택하여 전역 모수·외래 연령 비중 π·비인플루엔자 기저 회귀를 전부 다시 추정한다. 코로나19 후향 검증(covid_valid.py)은 변이 점유율 증가분 DV를 기점 이후 0으로 설정한다. 문제 2 본 전망의 기점은 2026-39주이며 그 이후 관측은 어떤 형태로도 입력에 쓰지 않았다.',
'실행 방법':'python 3.11+, numpy·scipy·pandas·matplotlib·openpyxl (requirements.txt). bash run_all.sh 한 번으로 적합부터 제출 파일까지 재생성된다(2 CPU 기준 약 60분). 난수 씨앗 고정. 개별 단계는 README.md의 실행 순서 참조.',
'1-나 → 1-다 변경 기록':'문제 1은 별도 모형(SIR beta regression + GBM)으로 수행하였으며 1-나와 1-다 사이에 모형 변경 없음. 다만 1-다(2026-39 기점)의 제출값은 문제 2 모형(연령구조 공통접촉 SEIR)의 대표 전망 ILI 분위수를 사용하였다. 2차 배포 자료(2026-35~39주)를 받은 뒤 전체 재적합과 nowcast를 수행하였고, 그 과정에서 관측 척도 κ를 자유 추정에서 문헌값 0.58 고정으로 바꾸었다(절대 감염 규모의 식별 문제 때문. 변경 후 모형 산출 의료이용 453만 건이 건강보험 청구 387만 건과 같은 규모로 확인됨).',
'대표 전망의 시나리오 가중치':'가중 혼합이 아닌 무조건 예측이다. A(H3N2)·B의 유입 여부·시점·초기 감수성을 과거 8개 절기 추정값의 경험분포에서 직접 추출하였다(A(H3N2) 8/8절기, B 5/8절기, 유입 주차는 과거 검출 개시 주차 ±2주). 여름 신규 계통 유입은 과거 9개 여름 중 2회 관측에 따라 확률 2/9로 포함. 코로나19는 계통 교체를 연 2.8회(2024.7~2026.8 6회) 포아송 과정으로 추출하고 회피 크기는 과거 추정값에서 추출.',
'공통 시나리오 근사 방법':'아형·변이를 명시적으로 다루는 모형이므로 전파력 승수 근사를 쓰지 않았다. F1: A(H3N2)·B 유입을 넣지 않음. F2: 2026-45~47주 A(H3N2) 유입, 초기 감수성 인구 비율을 2025-26절기 적합값 0.69로 설정("같은 규모의 파동 잠재력"을 추정값으로 번역). C1: 2026년 8월 이후 신규 계통 점유율 증가를 0으로 둠. C2: 2026-50주에 점유율 50%가 되는 로지스틱 곡선을 넣고, 그 기간 회복자 중 일부를 감수성으로 되돌림. 되돌리는 비율은 과거 실제 유행을 일으킨 계통군의 추정값 × U(1.0, 1.3)로, "중화항체 40% 이상 저하"를 집단 수준 양으로 근사하였다.',
'가장 불안한 가정 하나':'현재 A(H1N1)pdm09의 초기 감수성 인구 비율 s ≈ 0.90. 여름 유행으로 이미 면역 획득이 많이 진행되었다면(s=0.60) 정점은 85에서 54로 낮아지고 시기는 2026-43주에서 12월 이후로 이동한다. 2026-40~41주 관측이 이를 가장 먼저 판정한다.',
'대형언어모형 사용 범위':'코드 작성, 문헌 정리, 보고서·발표자료 초안 작성, 그림 생성에 사용. 모형 구조 설계와 가정 선택, 결과 해석은 팀이 결정하였고 모든 수치는 제출 코드의 실행 결과이다.',
'한계':'① 접촉행렬은 Prem 등(2017, 2021)의 장소층 구조에 POLYMOD·국내 접촉조사 범위의 평균 접촉 수를 맞춘 근사이며 원자료 수치가 아니다. ② 관측 척도 κ의 구성요소 중 "증상자의 의원 방문 확률 50%"는 가정값으로, 30%·70%로 바꾸면 정점 중앙값이 58·145로 변한다(시기와 접종 시기 효과의 방향은 유지). ③ 연령별 외래 이용률 차이를 반영하지 않아 13-18세를 과대, 7-12세를 과소 추정한다. ④ 아형 간 고유 전파력은 같다고 가정하였다. ⑤ 코로나19는 계통군별 재감염 전환 비율·면역 지속기간·R0가 서로 상충하여 추정 구간이 넓고, 2024년 여름 정점을 과대추정한다. ⑥ 후향 검증(38주 기점, 3개 절기) 95% 구간 포함률 0.78로 명목 수준보다 좁다. ⑦ 백신의 중증·사망 예방효과는 비용 분석에 포함하지 않았다. ⑧ covid_sari는 건수가 적어 모형화하지 않았다.',
}
ws=wb['7.메타데이터']
for row in range(2,ws.max_row+1):
    k=ws.cell(row,1).value
    if k in M: ws.cell(row,2).value=M[k]

# --- 시트 5: 시나리오 정의 (대표 전망 REP 기술) ---
ws=wb['5.문제2_시나리오정의']
ROW=['REP','대표 전망 (무조건 예측, 시나리오 가중 혼합 아님)',
 'F1·F2·C1·C2처럼 가정을 하나로 고정하지 않고, 겨울 아형 유입과 코로나19 변이 교체를 '
 '"과거에 실제로 일어난 빈도"로 두었다. 인플루엔자: A(H3N2) 유입 확률 8/8절기, B형 5/8절기, '
 '유입 주차는 과거 검출 개시 주차 ±2주, 초기 감수성 인구 비율은 과거 8개 절기 추정값에서 추출. '
 '여름 신규 계통 유입은 확률 2/9. 코로나19: 계통 교체를 연 2.8회 포아송 과정, 회피 크기는 과거 추정값에서 추출.',
 '과거 8개 절기(2016-17~2025-26, 코로나19 방역기 제외) 본 모형 적합값의 경험분포. '
 'A(H3N2)는 8개 절기 모두, B형은 5개 절기에서 검출률 기준 유행이 관측되었다. '
 '여름 유행은 코로나19 방역기를 제외한 9개 여름 중 2회(2023, 2026) 27~35주 유행기준을 초과하였다. '
 '코로나19 계통군 교체는 2024.7~2026.8 사이 6회 관측(질병관리청 변이 점유율 자료) → 연 2.8회.',
 'forecast_flu.py의 run("REP"): 표본마다 ① A(H3N2)·B의 유입 여부를 과거 빈도로 베르누이 추출 '
 '② 유입 주차를 과거 개시 주차 분포에서 추출 ③ 초기 감수성 수준 s를 과거 절기 적합값에서 추출 '
 '④ 확률 2/9로 2027년 22~30주에 신규 계통 유입(해당 아형 감수성을 현재 A(H1N1)pdm09 수준으로 재설정). '
 'forecast_covid.py의 run("REP"): 포아송으로 뽑은 교체 횟수만큼 로지스틱 점유율 곡선을 넣고 '
 '회피 크기 e를 과거 계통군 추정값에서 추출. 두 병원체 모두 과정잡음 AR(1)(rho=0.8, sd=0.05)을 더한다.',
 '대표 전망 자체이므로 차이는 공통 시나리오 대비로 기술한다. ILI 정점 85(80% 61-117)로 '
 'F1(80)과 F2(94) 사이. 절기 누적 1,101로 F1 839, F2 1,152 사이. 2026-50주 이후 ILI 30 초과 확률은 '
 'F1 1%, F2 100%인 반면 REP는 80%. 코로나19 입원 누적 5,159로 C1 3,687과 C2 6,408 사이.',
 '① 2026-48주 이후 A(H3N2)+B 검출률 합이 5%를 넘는지 (REP의 초과 확률 98%) '
 '② 그 시점이 2026-45~50주 범위인지 ③ 코로나19 신규 계통 점유율이 2027-35주까지 50%에 도달하는 횟수가 '
 '2~3회인지 ④ 2027-27~35주 ILI가 유행기준 12.9를 넘는지 (REP 확률 4.6%)']
for j,v in enumerate(ROW): ws.cell(2,1+j).value=v
for j in range(1,8): ws.cell(3,j).value=None     # U2 행 비움

wb.save(DST); print('saved',DST)
