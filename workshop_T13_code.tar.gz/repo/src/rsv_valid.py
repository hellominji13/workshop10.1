"""RSV 후향 검증: 기점(40주)까지 자료로 재적합 → 이듬해 17주까지 전망 → WIS (기준모형 비교)."""
import numpy as np, pickle, common as c, rsv
from scipy.optimize import least_squares
from valid_forecast import wis, QL
full=pickle.load(open('rsv_fit.pkl','rb'))['x']; R={}
for O in [202340,202440]:
    W=c.week_range(201501,O); obs=rsv.OBS[:len(W)]
    res=lambda p: np.log(rsv.sim(p,W)+20)-np.log(obs+20)
    sol=least_squares(res,full,bounds=(rsv.LB,rsv.UB),max_nfev=100)
    J=sol.jac; s2=(sol.fun**2).sum()/(len(sol.fun)-len(sol.x)); cov=np.linalg.pinv(J.T@J)*s2*9
    FW=c.week_range(c.next_week(O),(O//100+1)*100+17); y=np.array([rsv.OBS[rsv.W.index(w)] for w in FW])
    rng=np.random.default_rng(1); H=[]
    for j in range(150):
        p=np.clip(rng.multivariate_normal(sol.x,cov),rsv.LB,rsv.UB); _,st=rsv.sim(p,W,ret_state=True)
        H.append(rsv.sim(p,FW,state=st)*np.exp(rng.normal(0,0.15))*np.exp(rng.normal(0,0.1,len(FW))))
    H=np.array(H); q=np.quantile(H,QL,axis=0); S=np.mean([wis(q[:,k],y[k]) for k in range(len(FW))])
    hist=rsv.OBS[:len(W)]; qb=np.zeros((7,len(FW)))
    for h in range(1,len(FW)+1):
        d=hist[h:]-hist[:-h]; d=np.r_[d,-d]; qb[:,h-1]=np.maximum(hist[-1]+np.quantile(d,QL),0)
    SB=np.mean([wis(qb[:,k],y[k]) for k in range(len(FW))])
    cov95=np.mean((y>=q[0])&(y<=q[6])); R[O]=dict(FW=FW,q=q,y=y,wis=S,base=SB,cov95=cov95,pk=(y.max(),np.quantile(H.max(1),[.1,.5,.9])),pkw=(FW[int(y.argmax())],FW[int(np.median(H.argmax(1)))]))
    print(O,'WIS',round(S,1),'base',round(SB,1),'cov95',round(cov95,2),'peak obs',y.max(),'pred',R[O]['pk'][1].round(0),'peak wk obs/pred',R[O]['pkw'])
pickle.dump(R,open('rsv_valid.pkl','wb'))
