import numpy as np, pickle, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import common as c, flu, fit_flu as ff
plt.rcParams['font.family']='Noto Sans CJK JP'
fit=pickle.load(open('flu_fit.pkl','rb')); g,loc=ff.unpack(fit['x']); r,keep=ff.resid(fit['x'],True)
A=ff.AGE; seas={'2017-2018':1,'2018-2019':2,'2019-2020':3,'2024-2025':6,'2025-2026':7}
fig,ax=plt.subplots(1,5,figsize=(20,4)); cols=plt.cm.viridis(np.linspace(0,0.9,6)); out=[]
for k,(s,i) in enumerate(seas.items()):
    w,inc,tot,age=keep[i]; a=A[(A.s==s)&A.yw.isin(w)]; idx=[w.index(y) for y in a.yw]
    hol=np.array([g['hrep'] if y in c.HOLIDAY else 1 for y in a.yw])
    m=age[idx]*np.exp(g['logkA'])*hol[:,None]; o=a[c.AGES].values*ff.F.loc[a.yw,'pos'].values[:,None]/100
    for j in range(6):
        ax[k].plot(o[:,j],'o',ms=2.5,color=cols[j]); ax[k].plot(m[:,j],'-',color=cols[j],label=c.AGES[j])
    # 연령별 누적 비중 비교
    out.append((s,(o.sum(0)/o.sum()).round(2),(m.sum(0)/m.sum()).round(2)))
    ax[k].set_title(s); 
ax[0].legend(fontsize=8); fig.suptitle('연령별 ILI+ (점=관측 연령별 ILI×검출률, 선=모형) — 아형별 연령 감수성 프로필 검증'); fig.tight_layout(); fig.savefig('fig/flu_age_fit.png',dpi=100)
for o in out: print(o)
sig=ff.sigma(g); print('sigma',dict(zip(flu.SUB,sig.round(2))))
