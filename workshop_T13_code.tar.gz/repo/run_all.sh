#!/usr/bin/env bash
# 2026 예측네트워크 추계 워크숍 — 팀 T13 문제 2·3 전체 재현
# 사용법:  bash run_all.sh            (자료는 ../data 또는 $DATA_DIR)
# 소요 시간: 2 CPU 기준 약 60분. 난수 씨앗 고정.
set -euo pipefail
cd "$(dirname "$0")/src"
export PYTHONPATH="$PWD:${PYTHONPATH:-}"
step(){ echo; echo "=== [$(date +%H:%M:%S)] $* ==="; }

step "1/9  비인플루엔자 ILI 기저 회귀"
python3 make_bg.py

step "2/9  인플루엔자 9개 절기 적합 (약 6분)"
python3 fit_flu.py

step "3/9  입원 연결 + 의료이용 외부 검증"
python3 hosp_flu.py

step "4/9  2026 A(H1N1)pdm09 파동 nowcast"
python3 flu_now.py

step "5/9  코로나19 적합 (차분진화, 약 5분)"
python3 fit_covid.py HARM 0.584 0.293
cp covid_fit_HARM.pkl covid_fit_best.pkl
python3 joint_contact.py covid_fit_best.pkl     # 공통 접촉 모수 공동 프로파일

step "6/9  시나리오 전망"
python3 forecast_flu.py
python3 forecast_covid.py covid_fit_best.pkl
python3 outputs.py                               # Q-a/Q-b/Q-c + 장형 csv
python3 policy.py                                # 접종 정책 비교
python3 sens_s.py                                # 초기 감수성 민감도

step "7/9  후향 검증"
for y in 2023 2024 2025; do python3 valid_fit.py $y; done
PNOISE=0.05 python3 valid_forecast.py
python3 covid_valid.py

step "8/9  문제 3 (RSV + 변이 침입 적합도 + 접종 배분)"
python3 rsv.py; python3 rsv_fc.py; python3 rsv_valid.py
python3 evo2.py; python3 evo_opt2.py
python3 opt_flu.py; python3 opt_keep65.py; python3 opt_robust.py

step "9/9  그림과 제출 파일"
for f in plot_flu_fit plot_age plot_cov_fc plot_valid figs_extra figs_v2 \
         fig_simple fig_brief fig_variant fig_q3 fig_evo fig_cov_one fig_valid_extra \
         fig_latent fig_latent2; do python3 $f.py; done
python3 plot_covid.py covid_fit_best.pkl
python3 fill_submission.py ../outputs/T13_template.xlsx ../outputs/submission_T13.xlsx

echo; echo "완료. 그림은 src/fig/, 제출 파일은 outputs/submission_T13.xlsx"
